
DROP TRIGGER IF EXISTS trg_bump_reject_ins ON public.submissions;
DROP TRIGGER IF EXISTS trg_bump_reject_upd ON public.submissions;
DROP TRIGGER IF EXISTS trg_enforce_submission_rules ON public.submissions;
