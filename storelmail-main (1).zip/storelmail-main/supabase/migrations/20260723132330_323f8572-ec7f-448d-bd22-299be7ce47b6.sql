
-- Seed default admin account if it does not already exist.
-- Uses pgcrypto to hash the password with bcrypt as Supabase Auth expects.
DO $$
DECLARE
  admin_email text := 'warrentionardy3500@gmail.com';
  admin_password text := 'admin123.elmail';
  new_id uuid;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE email = admin_email) THEN
    new_id := gen_random_uuid();
    INSERT INTO auth.users (
      instance_id, id, aud, role, email, encrypted_password,
      email_confirmed_at, raw_app_meta_data, raw_user_meta_data,
      created_at, updated_at, is_super_admin, is_sso_user, is_anonymous
    ) VALUES (
      '00000000-0000-0000-0000-000000000000', new_id, 'authenticated', 'authenticated',
      admin_email, crypt(admin_password, gen_salt('bf')),
      now(), '{"provider":"email","providers":["email"]}'::jsonb, '{}'::jsonb,
      now(), now(), false, false, false
    );
    INSERT INTO auth.identities (
      id, user_id, provider_id, identity_data, provider, last_sign_in_at, created_at, updated_at
    ) VALUES (
      gen_random_uuid(), new_id, new_id::text,
      jsonb_build_object('sub', new_id::text, 'email', admin_email, 'email_verified', true),
      'email', now(), now(), now()
    );
    -- profiles and user_roles rows are created by handle_new_user() trigger
    -- but ensure admin role is set (trigger already handles this specific email)
    INSERT INTO public.user_roles (user_id, role) VALUES (new_id, 'admin')
      ON CONFLICT (user_id, role) DO NOTHING;
  ELSE
    -- If account exists, ensure admin role
    INSERT INTO public.user_roles (user_id, role)
    SELECT id, 'admin'::public.app_role FROM auth.users WHERE email = admin_email
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
END $$;
