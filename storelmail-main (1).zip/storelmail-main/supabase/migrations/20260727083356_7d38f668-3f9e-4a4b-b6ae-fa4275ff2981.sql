-- 1. Password categories
CREATE TABLE IF NOT EXISTS public.password_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text NOT NULL DEFAULT '',
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.password_categories TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.password_categories TO authenticated;
GRANT ALL ON public.password_categories TO service_role;

ALTER TABLE public.password_categories ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Anyone can view password categories" ON public.password_categories;
CREATE POLICY "Anyone can view password categories"
  ON public.password_categories FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admins manage password categories" ON public.password_categories;
CREATE POLICY "Admins manage password categories"
  ON public.password_categories FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

DROP TRIGGER IF EXISTS trg_password_categories_updated_at ON public.password_categories;
CREATE TRIGGER trg_password_categories_updated_at
  BEFORE UPDATE ON public.password_categories
  FOR EACH ROW EXECUTE FUNCTION public.rules_set_updated_at();

INSERT INTO public.password_categories (name, sort_order)
VALUES ('AASS1122', 1), ('PRABUJAYA', 2), ('FINEIRGA', 3)
ON CONFLICT (name) DO NOTHING;

-- 2. Submission fields (backward compatible, all nullable / defaulted)
ALTER TABLE public.submissions
  ADD COLUMN IF NOT EXISTS password_category_id uuid REFERENCES public.password_categories(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS password_category_name text,
  ADD COLUMN IF NOT EXISTS is_valid_prefix boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS validation_reason text NOT NULL DEFAULT 'Valid Prefix';

CREATE INDEX IF NOT EXISTS idx_submissions_password_category ON public.submissions(password_category_id);
CREATE INDEX IF NOT EXISTS idx_submissions_is_valid_prefix ON public.submissions(is_valid_prefix);

-- Backfill legacy rows with the default category name
UPDATE public.submissions s
SET password_category_name = COALESCE(s.password_category_name, 'AASS1122')
WHERE s.password_category_name IS NULL;

UPDATE public.submissions s
SET password_category_id = c.id
FROM public.password_categories c
WHERE s.password_category_id IS NULL AND c.name = s.password_category_name;

-- 3. Realtime
ALTER TABLE public.password_categories REPLICA IDENTITY FULL;
DO $$
BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.password_categories;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
END $$;