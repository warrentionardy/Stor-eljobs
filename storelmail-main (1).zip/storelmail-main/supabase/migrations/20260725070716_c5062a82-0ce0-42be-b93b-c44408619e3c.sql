
-- Add 'processing' to submission_status enum
ALTER TYPE public.submission_status ADD VALUE IF NOT EXISTS 'processing' BEFORE 'accepted';

-- Add review tracking columns
ALTER TABLE public.submissions
  ADD COLUMN IF NOT EXISTS approved_at timestamptz,
  ADD COLUMN IF NOT EXISTS approved_by uuid REFERENCES auth.users(id),
  ADD COLUMN IF NOT EXISTS rejected_at timestamptz,
  ADD COLUMN IF NOT EXISTS rejected_by uuid REFERENCES auth.users(id),
  ADD COLUMN IF NOT EXISTS rejection_reason text;

-- Update award_referral_on_accept to only fire on true transition into 'accepted'
CREATE OR REPLACE FUNCTION public.award_referral_on_accept()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  rs jsonb;
  enabled boolean;
  points numeric;
  ref_row public.referrals%ROWTYPE;
BEGIN
  IF NEW.status IS DISTINCT FROM 'accepted' THEN RETURN NEW; END IF;
  IF TG_OP = 'UPDATE' AND OLD.status = 'accepted' THEN RETURN NEW; END IF;

  SELECT value INTO rs FROM public.app_settings WHERE key = 'referral_settings';
  IF rs IS NULL THEN RETURN NEW; END IF;
  enabled := COALESCE((rs->>'enabled')::boolean, false);
  IF NOT enabled THEN RETURN NEW; END IF;
  points := COALESCE((rs->>'points_per_approved')::numeric, 0);

  SELECT * INTO ref_row FROM public.referrals WHERE referred_user_id = NEW.user_id;
  IF NOT FOUND THEN RETURN NEW; END IF;

  INSERT INTO public.referral_rewards (referral_id, submission_id, points_awarded)
  VALUES (ref_row.id, NEW.id, points)
  ON CONFLICT (submission_id) DO NOTHING;
  RETURN NEW;
END;
$function$;

-- Keep reject counter accurate across new state transitions
CREATE OR REPLACE FUNCTION public.bump_reject_count()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF (TG_OP = 'INSERT' AND NEW.status = 'rejected') THEN
    UPDATE public.profiles SET reject_count = reject_count + 1 WHERE id = NEW.user_id;
  ELSIF (TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status AND NEW.status = 'rejected') THEN
    UPDATE public.profiles SET reject_count = reject_count + 1 WHERE id = NEW.user_id;
  END IF;
  RETURN NEW;
END;
$function$;
