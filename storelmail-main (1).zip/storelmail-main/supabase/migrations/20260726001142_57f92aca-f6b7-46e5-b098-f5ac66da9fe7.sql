
-- 1) Ensure required triggers are attached
DROP TRIGGER IF EXISTS trg_enforce_submission ON public.submissions;
CREATE TRIGGER trg_enforce_submission
  BEFORE INSERT ON public.submissions
  FOR EACH ROW EXECUTE FUNCTION public.enforce_submission_rules();

DROP TRIGGER IF EXISTS trg_enforce_withdrawal ON public.withdrawals;
CREATE TRIGGER trg_enforce_withdrawal
  BEFORE INSERT ON public.withdrawals
  FOR EACH ROW EXECUTE FUNCTION public.enforce_withdrawal_rules();

DROP TRIGGER IF EXISTS trg_bump_reject ON public.submissions;
CREATE TRIGGER trg_bump_reject
  AFTER INSERT OR UPDATE OF status ON public.submissions
  FOR EACH ROW EXECUTE FUNCTION public.bump_reject_count();

DROP TRIGGER IF EXISTS trg_rules_updated_at ON public.rules;
CREATE TRIGGER trg_rules_updated_at
  BEFORE UPDATE ON public.rules
  FOR EACH ROW EXECUTE FUNCTION public.rules_set_updated_at();

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 2) Referral reward history (audit log)
CREATE TABLE IF NOT EXISTS public.referral_reward_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id UUID NOT NULL,
  referred_user_id UUID NOT NULL,
  submission_id UUID NOT NULL,
  reward_amount NUMERIC NOT NULL DEFAULT 0,
  action TEXT NOT NULL CHECK (action IN ('granted','rolled_back')),
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT ON public.referral_reward_history TO authenticated;
GRANT ALL ON public.referral_reward_history TO service_role;

ALTER TABLE public.referral_reward_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users view own reward history" ON public.referral_reward_history;
CREATE POLICY "Users view own reward history"
  ON public.referral_reward_history FOR SELECT
  TO authenticated
  USING (
    auth.uid() = referrer_id
    OR auth.uid() = referred_user_id
    OR public.has_role(auth.uid(), 'admin')
  );

CREATE INDEX IF NOT EXISTS idx_reward_history_referrer ON public.referral_reward_history(referrer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reward_history_submission ON public.referral_reward_history(submission_id);

-- 3) Updated referral grant function: writes audit
CREATE OR REPLACE FUNCTION public.award_referral_on_accept()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  rs jsonb; enabled boolean; points numeric;
  ref_row public.referrals%ROWTYPE;
  inserted_id uuid;
BEGIN
  IF NEW.status IS DISTINCT FROM 'accepted' THEN RETURN NEW; END IF;
  IF TG_OP = 'UPDATE' AND OLD.status = 'accepted' THEN RETURN NEW; END IF;

  SELECT value INTO rs FROM public.app_settings WHERE key = 'referral_settings';
  IF rs IS NULL THEN RETURN NEW; END IF;
  enabled := COALESCE((rs->>'enabled')::boolean, false);
  IF NOT enabled THEN RETURN NEW; END IF;
  points := COALESCE((rs->>'points_per_approved')::numeric, 0);

  SELECT * INTO ref_row FROM public.referrals WHERE referred_user_id = NEW.user_id;
  IF NOT FOUND THEN RETURN NEW; END IF;

  INSERT INTO public.referral_rewards (referral_id, submission_id, points_awarded)
  VALUES (ref_row.id, NEW.id, points)
  ON CONFLICT (submission_id) DO NOTHING
  RETURNING id INTO inserted_id;

  IF inserted_id IS NOT NULL THEN
    INSERT INTO public.referral_reward_history (referrer_id, referred_user_id, submission_id, reward_amount, action, notes)
    VALUES (ref_row.referrer_id, NEW.user_id, NEW.id, points, 'granted', 'Submission diterima');

    -- Notify referrer
    INSERT INTO public.notifications (user_id, category, title, message)
    VALUES (ref_row.referrer_id, 'system', 'Hadiah Referral Diterima', 'Anda mendapat ' || points || ' poin dari setoran referral yang disetujui.');
  END IF;
  RETURN NEW;
END;
$function$;

-- 4) Rollback function when accepted -> other status
CREATE OR REPLACE FUNCTION public.rollback_referral_on_revert()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  removed_row public.referral_rewards%ROWTYPE;
  ref_row public.referrals%ROWTYPE;
BEGIN
  IF TG_OP <> 'UPDATE' THEN RETURN NEW; END IF;
  IF OLD.status = 'accepted' AND NEW.status IS DISTINCT FROM 'accepted' THEN
    SELECT * INTO removed_row FROM public.referral_rewards WHERE submission_id = OLD.id;
    IF FOUND THEN
      DELETE FROM public.referral_rewards WHERE submission_id = OLD.id;
      SELECT * INTO ref_row FROM public.referrals WHERE id = removed_row.referral_id;
      IF FOUND THEN
        INSERT INTO public.referral_reward_history (referrer_id, referred_user_id, submission_id, reward_amount, action, notes)
        VALUES (ref_row.referrer_id, ref_row.referred_user_id, OLD.id, removed_row.points_awarded, 'rolled_back', 'Status setoran dikembalikan: '||NEW.status);
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS trg_award_referral ON public.submissions;
CREATE TRIGGER trg_award_referral
  AFTER INSERT OR UPDATE OF status ON public.submissions
  FOR EACH ROW EXECUTE FUNCTION public.award_referral_on_accept();

DROP TRIGGER IF EXISTS trg_rollback_referral ON public.submissions;
CREATE TRIGGER trg_rollback_referral
  AFTER UPDATE OF status ON public.submissions
  FOR EACH ROW EXECUTE FUNCTION public.rollback_referral_on_revert();

-- 5) Backfill any previously-accepted submissions that never received a reward
INSERT INTO public.referral_rewards (referral_id, submission_id, points_awarded)
SELECT r.id, s.id, COALESCE(((SELECT value FROM public.app_settings WHERE key='referral_settings')->>'points_per_approved')::numeric, 0)
FROM public.submissions s
JOIN public.referrals r ON r.referred_user_id = s.user_id
WHERE s.status = 'accepted'
ON CONFLICT (submission_id) DO NOTHING;

INSERT INTO public.referral_reward_history (referrer_id, referred_user_id, submission_id, reward_amount, action, notes)
SELECT r.referrer_id, r.referred_user_id, rr.submission_id, rr.points_awarded, 'granted', 'Backfill: setoran diterima'
FROM public.referral_rewards rr
JOIN public.referrals r ON r.id = rr.referral_id
LEFT JOIN public.referral_reward_history h ON h.submission_id = rr.submission_id AND h.action='granted'
WHERE h.id IS NULL;

-- 6) Search / performance indexes
CREATE INDEX IF NOT EXISTS idx_submissions_gmail_trgm ON public.submissions (gmail);
CREATE INDEX IF NOT EXISTS idx_submissions_user ON public.submissions (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_submissions_status_created ON public.submissions (status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_submissions_batch ON public.submissions (batch_id);
