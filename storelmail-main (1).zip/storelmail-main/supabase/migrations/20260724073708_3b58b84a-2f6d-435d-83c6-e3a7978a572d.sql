
-- 1. Profiles: referral_code + referred_by
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS referral_code text UNIQUE,
  ADD COLUMN IF NOT EXISTS referred_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;

-- Referral code generator
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  code text;
  exists_flag boolean;
BEGIN
  LOOP
    code := 'ELM' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 4));
    SELECT EXISTS(SELECT 1 FROM public.profiles WHERE referral_code = code) INTO exists_flag;
    EXIT WHEN NOT exists_flag;
  END LOOP;
  RETURN code;
END;
$$;

-- Backfill referral_code for existing profiles
UPDATE public.profiles SET referral_code = public.generate_referral_code() WHERE referral_code IS NULL;

-- 2. referrals table
CREATE TABLE IF NOT EXISTS public.referrals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  referred_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  referral_code text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(referred_user_id)
);
GRANT SELECT ON public.referrals TO authenticated;
GRANT ALL ON public.referrals TO service_role;
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users view own referrals" ON public.referrals;
CREATE POLICY "Users view own referrals" ON public.referrals FOR SELECT TO authenticated
  USING (auth.uid() = referrer_id OR auth.uid() = referred_user_id OR public.has_role(auth.uid(), 'admin'));

-- 3. referral_rewards
CREATE TABLE IF NOT EXISTS public.referral_rewards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referral_id uuid NOT NULL REFERENCES public.referrals(id) ON DELETE CASCADE,
  submission_id uuid NOT NULL REFERENCES public.submissions(id) ON DELETE CASCADE,
  points_awarded numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(submission_id)
);
GRANT SELECT ON public.referral_rewards TO authenticated;
GRANT ALL ON public.referral_rewards TO service_role;
ALTER TABLE public.referral_rewards ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users view own rewards" ON public.referral_rewards;
CREATE POLICY "Users view own rewards" ON public.referral_rewards FOR SELECT TO authenticated
  USING (
    public.has_role(auth.uid(), 'admin') OR
    EXISTS (SELECT 1 FROM public.referrals r WHERE r.id = referral_id AND (r.referrer_id = auth.uid() OR r.referred_user_id = auth.uid()))
  );

-- 4. Award trigger on submissions
CREATE OR REPLACE FUNCTION public.award_referral_on_accept()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  rs jsonb;
  enabled boolean;
  points numeric;
  min_status text;
  ref_row public.referrals%ROWTYPE;
BEGIN
  IF NEW.status IS DISTINCT FROM 'accepted' THEN RETURN NEW; END IF;
  IF TG_OP = 'UPDATE' AND OLD.status = 'accepted' THEN RETURN NEW; END IF;

  SELECT value INTO rs FROM public.app_settings WHERE key = 'referral_settings';
  IF rs IS NULL THEN RETURN NEW; END IF;
  enabled := COALESCE((rs->>'enabled')::boolean, false);
  IF NOT enabled THEN RETURN NEW; END IF;
  points := COALESCE((rs->>'points_per_approved')::numeric, 0);
  min_status := COALESCE(rs->>'min_status', 'accepted');

  IF NEW.status <> min_status THEN RETURN NEW; END IF;

  SELECT * INTO ref_row FROM public.referrals WHERE referred_user_id = NEW.user_id;
  IF NOT FOUND THEN RETURN NEW; END IF;

  INSERT INTO public.referral_rewards (referral_id, submission_id, points_awarded)
  VALUES (ref_row.id, NEW.id, points)
  ON CONFLICT (submission_id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_award_referral ON public.submissions;
CREATE TRIGGER trg_award_referral
AFTER INSERT OR UPDATE OF status ON public.submissions
FOR EACH ROW EXECUTE FUNCTION public.award_referral_on_accept();

-- 5. Update handle_new_user to generate referral_code + link referrer
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  ref_code text;
  referrer uuid;
  new_code text;
BEGIN
  new_code := public.generate_referral_code();
  INSERT INTO public.profiles (id, email, username, referral_code)
  VALUES (new.id, new.email, split_part(coalesce(new.email, 'user'), '@', 1), new_code)
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (new.id, CASE WHEN new.email = 'warrentionardy3500@gmail.com' THEN 'admin'::public.app_role ELSE 'user'::public.app_role END)
  ON CONFLICT DO NOTHING;

  ref_code := new.raw_user_meta_data->>'referral_code';
  IF ref_code IS NOT NULL AND length(trim(ref_code)) > 0 THEN
    SELECT id INTO referrer FROM public.profiles WHERE upper(referral_code) = upper(trim(ref_code));
    IF referrer IS NOT NULL AND referrer <> new.id THEN
      UPDATE public.profiles SET referred_by = referrer WHERE id = new.id;
      INSERT INTO public.referrals (referrer_id, referred_user_id, referral_code)
      VALUES (referrer, new.id, upper(trim(ref_code)))
      ON CONFLICT (referred_user_id) DO NOTHING;
    END IF;
  END IF;
  RETURN new;
END;
$$;

-- 6. Improve storan open/close: manual override
CREATE OR REPLACE FUNCTION public.is_storan_open()
RETURNS boolean
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  s jsonb;
  manual jsonb;
  storan_flag jsonb;
  enabled_val boolean;
  ot time; ct time; tz text; nowt time;
BEGIN
  SELECT value INTO manual FROM public.app_settings WHERE key = 'storan_manual_override';
  IF manual IS NOT NULL AND (manual::text)::boolean = true THEN
    SELECT value INTO storan_flag FROM public.app_settings WHERE key = 'storan_enabled';
    RETURN COALESCE((storan_flag::text)::boolean, true);
  END IF;

  SELECT value INTO s FROM public.app_settings WHERE key = 'storan_schedule';
  IF s IS NULL THEN RETURN true; END IF;
  enabled_val := COALESCE((s->>'enabled')::boolean, false);
  IF NOT enabled_val THEN
    SELECT value INTO storan_flag FROM public.app_settings WHERE key = 'storan_enabled';
    RETURN COALESCE((storan_flag::text)::boolean, true);
  END IF;

  ot := (s->>'open_time')::time;
  ct := (s->>'close_time')::time;
  tz := COALESCE(s->>'timezone', 'Asia/Jakarta');
  nowt := (now() AT TIME ZONE tz)::time;

  IF ot = ct THEN RETURN true; END IF;
  IF ot < ct THEN
    RETURN nowt >= ot AND nowt < ct;
  ELSE
    RETURN nowt >= ot OR nowt < ct;
  END IF;
END;
$$;

-- 7. Seed referral_settings + manual override defaults
INSERT INTO public.app_settings (key, value) VALUES
  ('referral_settings', '{"enabled": true, "points_per_approved": 100, "min_status": "accepted", "description": "Dapatkan poin setiap Gmail yang disetor teman Anda disetujui."}'::jsonb),
  ('storan_manual_override', 'false'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- 8. Lookup RPC for referral_code -> validate at register
CREATE OR REPLACE FUNCTION public.validate_referral_code(_code text)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS(SELECT 1 FROM public.profiles WHERE upper(referral_code) = upper(trim(_code)));
$$;
GRANT EXECUTE ON FUNCTION public.validate_referral_code(text) TO anon, authenticated;

-- 9. Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.referrals;
ALTER PUBLICATION supabase_realtime ADD TABLE public.referral_rewards;
