
-- Full schema for Storel Maili platform
create extension if not exists pgcrypto;

create type public.app_role as enum ('admin', 'user');
create type public.submission_status as enum ('pending', 'accepted', 'rejected');
create type public.withdrawal_status as enum ('pending', 'approved', 'rejected', 'paid');
create type public.notification_category as enum ('submission', 'withdrawal', 'system', 'announcement');
create type public.user_status as enum ('active', 'suspended');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create policy "Users view own role" on public.user_roles for select to authenticated using (auth.uid() = user_id);
create policy "Admins view all roles" on public.user_roles for select to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "Admins manage roles" on public.user_roles for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  email text,
  avatar_url text,
  status public.user_status not null default 'active',
  reject_count integer not null default 0,
  dana_number text,
  dana_account_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "Users view own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "Users update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "Admins view all profiles" on public.profiles for select to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "Admins update all profiles" on public.profiles for update to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create table public.app_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);
grant select on public.app_settings to authenticated, anon;
grant all on public.app_settings to service_role;
alter table public.app_settings enable row level security;
create policy "Anyone can read settings" on public.app_settings for select using (true);
create policy "Admins manage settings" on public.app_settings for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

insert into public.app_settings (key, value) values
  ('minimum_withdrawal', '0'::jsonb),
  ('site_name', '"Storel Maili"'::jsonb),
  ('footer_text', '"Storel Maili — platform terpercaya."'::jsonb),
  ('community_whatsapp', '"https://chat.whatsapp.com/CfCC0jmX7pa7A0rAQo76Qa"'::jsonb),
  ('community_tiktok', '""'::jsonb),
  ('platform_password', '"aass1122"'::jsonb),
  ('storan_schedule', '{"enabled": false, "open_time": "08:00", "close_time": "22:00", "timezone": "Asia/Jakarta"}'::jsonb),
  ('storan_enabled', 'true'::jsonb),
  ('withdraw_enabled', 'true'::jsonb),
  ('withdraw_auto_approve', 'false'::jsonb),
  ('registration_enabled', 'true'::jsonb),
  ('login_enabled', 'true'::jsonb),
  ('email_verification', 'false'::jsonb),
  ('daily_submission_limit', '100'::jsonb),
  ('daily_withdraw_limit', '10'::jsonb),
  ('running_text', '"Selamat datang di Storel Maili"'::jsonb),
  ('dashboard_announcement', '""'::jsonb),
  ('landing_popup', '""'::jsonb),
  ('maintenance_mode', 'false'::jsonb),
  ('primary_color', '"#8b5cf6"'::jsonb),
  ('secondary_color', '"#0ea5e9"'::jsonb),
  ('theme', '"light"'::jsonb),
  ('landing_banner', '""'::jsonb);

create table public.submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  batch_id uuid not null default gen_random_uuid(),
  gmail text not null,
  status public.submission_status not null default 'pending',
  rate numeric(12,2) not null default 3000,
  notes text,
  reviewed_at timestamptz,
  reviewed_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index submissions_user_idx on public.submissions(user_id);
create index submissions_batch_idx on public.submissions(batch_id);
create index submissions_status_idx on public.submissions(status);
grant select, insert on public.submissions to authenticated;
grant all on public.submissions to service_role;
alter table public.submissions enable row level security;
create policy "Users view own submissions" on public.submissions for select to authenticated using (auth.uid() = user_id);
create policy "Users insert own submissions" on public.submissions for insert to authenticated with check (auth.uid() = user_id);
create policy "Admins view all submissions" on public.submissions for select to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "Admins update submissions" on public.submissions for update to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create table public.withdrawals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount numeric(12,2) not null check (amount > 0),
  payment_method text not null default 'DANA',
  account_number text not null,
  account_name text not null,
  status public.withdrawal_status not null default 'pending',
  admin_notes text,
  processed_at timestamptz,
  processed_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index withdrawals_user_idx on public.withdrawals(user_id);
create index withdrawals_status_idx on public.withdrawals(status);
grant select, insert on public.withdrawals to authenticated;
grant all on public.withdrawals to service_role;
alter table public.withdrawals enable row level security;
create policy "Users view own withdrawals" on public.withdrawals for select to authenticated using (auth.uid() = user_id);
create policy "Users create own withdrawals" on public.withdrawals for insert to authenticated with check (auth.uid() = user_id);
create policy "Admins view all withdrawals" on public.withdrawals for select to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "Admins update withdrawals" on public.withdrawals for update to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  message text not null,
  category public.notification_category not null default 'system',
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index notifications_user_idx on public.notifications(user_id, created_at desc);
grant select, insert, update on public.notifications to authenticated;
grant all on public.notifications to service_role;
alter table public.notifications enable row level security;
create policy "Users view own notifications" on public.notifications for select to authenticated using (auth.uid() = user_id);
create policy "Users update own notifications" on public.notifications for update to authenticated using (auth.uid() = user_id);
create policy "Admins insert notifications" on public.notifications for insert to authenticated with check (public.has_role(auth.uid(), 'admin') or auth.uid() = user_id);

create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  message text not null,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
grant select on public.announcements to authenticated, anon;
grant all on public.announcements to service_role;
alter table public.announcements enable row level security;
create policy "Anyone can read announcements" on public.announcements for select using (true);
create policy "Admins manage announcements" on public.announcements for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create table public.rules (
  id uuid primary key default gen_random_uuid(),
  is_active boolean not null default true,
  prefix text not null default '',
  price_match numeric not null default 0,
  price_no_match numeric not null default 0,
  required_password text not null default 'aass1122',
  notes text not null default '',
  updated_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select on public.rules to anon, authenticated;
grant insert, update, delete on public.rules to authenticated;
grant all on public.rules to service_role;
alter table public.rules enable row level security;
create policy "Anyone can view rules" on public.rules for select using (true);
create policy "Admins manage rules" on public.rules for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create or replace function public.rules_set_updated_at() returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end; $$;
create trigger trg_rules_updated_at before update on public.rules for each row execute function public.rules_set_updated_at();

insert into public.rules (is_active, prefix, price_match, price_no_match, required_password, notes)
values (true, 'de', 4500, 3500, 'aass1122', 'Password platform: aass1122');

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, username)
  values (new.id, new.email, split_part(coalesce(new.email, 'user'), '@', 1))
  on conflict (id) do nothing;
  insert into public.user_roles (user_id, role)
  values (new.id, case when new.email = 'warrentionardy3500@gmail.com' then 'admin'::public.app_role else 'user'::public.app_role end)
  on conflict do nothing;
  return new;
end; $$;

create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

create or replace function public.get_user_balance(_user_id uuid)
returns table (available numeric, pending numeric, lifetime numeric, withdrawn numeric)
language sql stable security definer set search_path = public as $$
  with earnings as (
    select coalesce(sum(case when status = 'accepted' then rate else 0 end), 0)::numeric as lifetime,
           coalesce(sum(case when status = 'pending' then rate else 0 end), 0)::numeric as pending
    from public.submissions where user_id = _user_id
  ),
  wd as (
    select coalesce(sum(case when status in ('approved','paid') then amount else 0 end), 0)::numeric as withdrawn,
           coalesce(sum(case when status = 'pending' then amount else 0 end), 0)::numeric as locked
    from public.withdrawals where user_id = _user_id
  )
  select (e.lifetime - w.withdrawn - w.locked)::numeric, e.pending, e.lifetime, w.withdrawn
  from earnings e, wd w;
$$;

revoke execute on function public.handle_new_user() from public, anon, authenticated;
grant execute on function public.has_role(uuid, public.app_role) to authenticated;
grant execute on function public.get_user_balance(uuid) to authenticated;

create or replace function public.is_storan_open()
returns boolean language plpgsql stable security definer set search_path = public as $$
declare
  s jsonb; enabled_val boolean; ot time; ct time; tz text; nowt time; storan_flag jsonb;
begin
  select value into storan_flag from public.app_settings where key = 'storan_enabled';
  if storan_flag is not null and (storan_flag::text)::boolean = false then return false; end if;
  select value into s from public.app_settings where key = 'storan_schedule';
  if s is null then return true; end if;
  enabled_val := coalesce((s->>'enabled')::boolean, false);
  if not enabled_val then return true; end if;
  ot := (s->>'open_time')::time;
  ct := (s->>'close_time')::time;
  tz := coalesce(s->>'timezone', 'Asia/Jakarta');
  nowt := (now() at time zone tz)::time;
  if ot <= ct then
    return nowt >= ot and nowt < ct;
  else
    return nowt >= ot or nowt < ct;
  end if;
end; $$;

grant execute on function public.is_storan_open() to authenticated, anon;

create or replace function public.enforce_submission_rules()
returns trigger language plpgsql security definer set search_path = public as $$
declare is_suspended boolean;
begin
  select (status = 'suspended') into is_suspended from public.profiles where id = new.user_id;
  if is_suspended then raise exception 'Akun Anda telah disuspend. Silakan hubungi Admin.'; end if;
  if not public.is_storan_open() then raise exception 'Storan sedang ditutup.'; end if;
  return new;
end; $$;

create trigger trg_enforce_submission_rules before insert on public.submissions
for each row execute function public.enforce_submission_rules();

create or replace function public.enforce_withdrawal_rules()
returns trigger language plpgsql security definer set search_path = public as $$
declare is_suspended boolean; wd_enabled jsonb;
begin
  select value into wd_enabled from public.app_settings where key = 'withdraw_enabled';
  if wd_enabled is not null and (wd_enabled::text)::boolean = false then
    raise exception 'Withdraw sedang dinonaktifkan.';
  end if;
  select (status = 'suspended') into is_suspended from public.profiles where id = new.user_id;
  if is_suspended then raise exception 'Akun Anda telah disuspend. Silakan hubungi Admin.'; end if;
  return new;
end; $$;

create trigger trg_enforce_withdrawal_rules before insert on public.withdrawals
for each row execute function public.enforce_withdrawal_rules();

create or replace function public.bump_reject_count()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (tg_op = 'INSERT' and new.status = 'rejected') then
    update public.profiles set reject_count = reject_count + 1 where id = new.user_id;
  elsif (tg_op = 'UPDATE' and (old.status is distinct from new.status) and new.status = 'rejected') then
    update public.profiles set reject_count = reject_count + 1 where id = new.user_id;
  end if;
  return new;
end; $$;

create trigger trg_bump_reject_ins after insert on public.submissions
for each row execute function public.bump_reject_count();
create trigger trg_bump_reject_upd after update on public.submissions
for each row execute function public.bump_reject_count();

alter publication supabase_realtime add table public.rules;
alter publication supabase_realtime add table public.submissions;
alter publication supabase_realtime add table public.withdrawals;
alter publication supabase_realtime add table public.profiles;
alter publication supabase_realtime add table public.app_settings;
alter publication supabase_realtime add table public.announcements;
alter publication supabase_realtime add table public.notifications;

-- Seed admin
DO $seed$
DECLARE
  admin_email text := 'warrentionardy3500@gmail.com';
  admin_password text := 'admin123.elmail';
  new_id uuid;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE email = admin_email) THEN
    new_id := gen_random_uuid();
    INSERT INTO auth.users (
      instance_id, id, aud, role, email, encrypted_password,
      email_confirmed_at, raw_app_meta_data, raw_user_meta_data,
      created_at, updated_at, is_super_admin, is_sso_user, is_anonymous
    ) VALUES (
      '00000000-0000-0000-0000-000000000000', new_id, 'authenticated', 'authenticated',
      admin_email, crypt(admin_password, gen_salt('bf')),
      now(), '{"provider":"email","providers":["email"]}'::jsonb, '{}'::jsonb,
      now(), now(), false, false, false
    );
    INSERT INTO auth.identities (
      id, user_id, provider_id, identity_data, provider, last_sign_in_at, created_at, updated_at
    ) VALUES (
      gen_random_uuid(), new_id, new_id::text,
      jsonb_build_object('sub', new_id::text, 'email', admin_email, 'email_verified', true),
      'email', now(), now(), now()
    );
    INSERT INTO public.user_roles (user_id, role) VALUES (new_id, 'admin')
      ON CONFLICT (user_id, role) DO NOTHING;
  ELSE
    INSERT INTO public.user_roles (user_id, role)
    SELECT id, 'admin'::public.app_role FROM auth.users WHERE email = admin_email
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
END $seed$;
