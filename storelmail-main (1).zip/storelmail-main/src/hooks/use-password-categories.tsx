import { useEffect, useId } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type PasswordCategory = {
  id: string;
  name: string;
  description: string;
  is_active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
};

function useCategoriesRealtime() {
  const qc = useQueryClient();
  const uid = useId();
  useEffect(() => {
    const ch = supabase
      .channel(`password-categories-live-${uid}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "password_categories" }, () => {
        qc.invalidateQueries({ queryKey: ["password_categories"] });
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc, uid]);
}

/** All categories (admin management). */
export function useAllPasswordCategories() {
  useCategoriesRealtime();
  return useQuery({
    queryKey: ["password_categories", "all"],
    queryFn: async (): Promise<PasswordCategory[]> => {
      const { data, error } = await supabase
        .from("password_categories")
        .select("*")
        .order("sort_order", { ascending: true })
        .order("name", { ascending: true });
      if (error) throw error;
      return (data ?? []) as PasswordCategory[];
    },
  });
}

/** Only enabled categories (user-facing). */
export function usePasswordCategories() {
  useCategoriesRealtime();
  return useQuery({
    queryKey: ["password_categories", "active"],
    queryFn: async (): Promise<PasswordCategory[]> => {
      const { data, error } = await supabase
        .from("password_categories")
        .select("*")
        .eq("is_active", true)
        .order("sort_order", { ascending: true })
        .order("name", { ascending: true });
      if (error) throw error;
      return (data ?? []) as PasswordCategory[];
    },
  });
}