import { useEffect, useId } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function useStoranOpen() {
  const qc = useQueryClient();
  const uid = useId();
  const query = useQuery({
    queryKey: ["storan_open"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("is_storan_open");
      if (error) throw error;
      return data as boolean;
    },
    staleTime: 0,
    refetchInterval: 15_000,
    refetchIntervalInBackground: true,
    refetchOnWindowFocus: true,
  });

  useEffect(() => {
    const ch = supabase
      .channel(`storan-live-${uid}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "app_settings" }, () => {
        qc.invalidateQueries({ queryKey: ["storan_open"] });
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [qc, uid]);

  return query;
}
