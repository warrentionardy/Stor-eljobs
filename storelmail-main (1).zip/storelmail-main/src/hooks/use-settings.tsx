import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type AppSettings = Record<string, unknown>;

export async function fetchAllSettings(): Promise<AppSettings> {
  const { data, error } = await supabase.from("app_settings").select("key, value");
  if (error) throw error;
  const out: AppSettings = {};
  (data ?? []).forEach((r) => {
    out[r.key] = r.value;
  });
  return out;
}

export function useSettings() {
  const qc = useQueryClient();
  const query = useQuery({ queryKey: ["app_settings"], queryFn: fetchAllSettings });

  useEffect(() => {
    const ch = supabase
      .channel("app-settings-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "app_settings" }, () => {
        qc.invalidateQueries({ queryKey: ["app_settings"] });
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  return query;
}

export function getSetting<T = unknown>(settings: AppSettings | undefined, key: string, fallback: T): T {
  if (!settings) return fallback;
  const v = settings[key];
  return (v === undefined || v === null ? fallback : (v as T));
}
