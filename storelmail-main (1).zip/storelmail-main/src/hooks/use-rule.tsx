import { useEffect, useId } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type Rule = {
  id: string;
  is_active: boolean;
  prefix: string;
  price_match: number;
  price_no_match: number;
  required_password: string;
  notes: string;
  updated_at: string;
};

export async function fetchActiveRule(): Promise<Rule | null> {
  const { data, error } = await supabase
    .from("rules")
    .select("*")
    .order("updated_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) throw error;
  return (data as Rule) ?? null;
}

// Shared realtime-backed hook for the single active rule.
export function useRule() {
  const qc = useQueryClient();
  const query = useQuery({ queryKey: ["rule"], queryFn: fetchActiveRule });
  const uid = useId();

  useEffect(() => {
    const channel = supabase
      .channel(`rules-live-${uid}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "rules" }, () => {
        qc.invalidateQueries({ queryKey: ["rule"] });
      })
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc, uid]);

  return query;
}
