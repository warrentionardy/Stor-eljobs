// Shared prefix validation + auto-generated example helpers.
// Never hardcode examples — everything derives from today's active rule prefix.

export const VALID_REASON = "Valid Prefix";
export const INVALID_REASON = "Prefix does not match today's rule";

export function normalizePrefix(prefix: string | null | undefined) {
  return (prefix ?? "").trim().toLowerCase();
}

export function checkPrefix(email: string, prefix: string | null | undefined) {
  const p = normalizePrefix(prefix);
  const local = (email.split("@")[0] ?? "").toLowerCase();
  if (!p) return { valid: true, reason: VALID_REASON };
  const valid = local.startsWith(p);
  return { valid, reason: valid ? VALID_REASON : INVALID_REASON };
}

export function buildExamples(prefix: string | null | undefined): { valid: string[]; invalid: string[] } {
  const p = normalizePrefix(prefix);
  if (!p) return { valid: [], invalid: [] };
  return {
    valid: [`${p}123@gmail.com`, `${p}gacor@gmail.com`, `${p}john@gmail.com`],
    invalid: [`agus123@gmail.com`, `abc123@gmail.com`, `racing${p}@gmail.com`],
  };
}