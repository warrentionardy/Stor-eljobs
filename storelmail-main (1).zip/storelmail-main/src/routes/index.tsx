import { createFileRoute } from "@tanstack/react-router";
import { SiteNav } from "@/components/site/nav";
import { SiteFooter } from "@/components/site/footer";
import { Hero } from "@/components/landing/hero";
import { Stats } from "@/components/landing/stats";
import { Features } from "@/components/landing/features";
import { HowItWorks } from "@/components/landing/how-it-works";
import { RulesToday } from "@/components/landing/rules-today";
import { Testimonials } from "@/components/landing/testimonials";
import { FAQ } from "@/components/landing/faq";
import { CTA } from "@/components/landing/cta";
import { useStoranOpen } from "@/hooks/use-storan";
import { useSettings, getSetting } from "@/hooks/use-settings";
import { AlertTriangle } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Landing,
  head: () => ({
    meta: [
      { title: "Storel Maili — Setor Gmail, dibayar cepat" },
      { name: "description", content: "Platform Storel Maili — setor akun Gmail yang memenuhi syarat, saldo real-time, dan penarikan DANA cepat." },
      { property: "og:title", content: "Storel Maili — Setor Gmail, dibayar cepat" },
      { property: "og:description", content: "Platform Storel Maili — setor akun Gmail yang memenuhi syarat, saldo real-time, dan penarikan DANA cepat." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function Landing() {
  const { data: storanOpen } = useStoranOpen();
  const { data: settings } = useSettings();
  const runningText = getSetting<string>(settings, "running_text", "");
  const banner = getSetting<string>(settings, "landing_banner", "");
  const popup = getSetting<string>(settings, "landing_popup", "");

  return (
    <div className="min-h-screen">
      <SiteNav />
      {runningText && (
        <div className="overflow-hidden bg-brand-accent/10 py-2 text-xs text-brand-accent">
          <div className="animate-marquee whitespace-nowrap px-4 font-medium">{runningText}</div>
        </div>
      )}
      {banner && (
        <div className="mx-auto max-w-6xl px-4 pt-4">
          <img src={banner} alt="Banner" className="w-full rounded-3xl object-cover" />
        </div>
      )}
      {storanOpen === false && (
        <div className="mx-auto mt-4 max-w-6xl px-4">
          <div className="glass flex items-center gap-3 rounded-3xl border border-destructive/30 bg-destructive/5 p-5 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            <div>
              <div className="font-semibold">Storan Sedang Ditutup</div>
              <div className="text-xs opacity-80">Silakan cek kembali sesuai jadwal buka storan.</div>
            </div>
          </div>
        </div>
      )}
      <main>
        <Hero />
        <Stats />
        <Features />
        <HowItWorks />
        <RulesToday />
        <Testimonials />
        <FAQ />
        <CTA />
      </main>
      <SiteFooter />
      {popup && (
        <div className="fixed bottom-4 right-4 z-40 max-w-sm">
          <div className="glass rounded-3xl border border-brand-accent/30 p-4 text-sm shadow-lg">{popup}</div>
        </div>
      )}
    </div>
  );
}
