import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";

export const Route = createFileRoute("/_authenticated/admin/payments")({
  component: () => (
    <div>
      <AppTopbar title="Manajemen Saldo" />
      <div className="mx-auto max-w-5xl p-4 md:p-6">
        <div className="glass rounded-3xl p-6 text-sm text-muted-foreground">
          Rekonsiliasi saldo terperinci akan segera hadir. Gunakan halaman Permintaan Penarikan untuk memproses pembayaran ke pengguna.
        </div>
      </div>
    </div>
  ),
});
