import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Check, X, Loader2, PlayCircle, Undo2, Search, ArrowDownUp, Filter } from "lucide-react";
import { toast } from "sonner";
import { dateTime, money } from "@/lib/format";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useRealtimeInvalidate } from "@/hooks/use-realtime";
import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { usePasswordCategories } from "@/hooks/use-password-categories";
import { PrefixBadge } from "@/components/app/prefix-badge";

export const Route = createFileRoute("/_authenticated/admin/queue")({
  component: QueuePage,
});

type SubmissionStatus = "pending" | "processing" | "accepted" | "rejected";
type StatusFilter = SubmissionStatus | "all" | "queue";
type RangeFilter = "all" | "today" | "week" | "month";

function QueuePage() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  useRealtimeInvalidate("submissions", [["admin-queue-all"]]);

  const [q, setQ] = useState("");
  const [status, setStatus] = useState<StatusFilter>("queue");
  const [range, setRange] = useState<RangeFilter>("all");
  const [sort, setSort] = useState<"newest" | "oldest">("oldest");
  const [cat, setCat] = useState<string>("all");
  const { data: categories } = usePasswordCategories();

  const { data, isLoading } = useQuery({
    queryKey: ["admin-queue-all"],
    queryFn: async () => {
      const { data: subs } = await supabase
        .from("submissions")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(1000);
      const rows = subs ?? [];
      const ids = Array.from(new Set(rows.map((r) => r.user_id)));
      let profMap: Record<string, { username: string | null; email: string | null }> = {};
      if (ids.length) {
        const { data: profs } = await supabase.from("profiles").select("id, username, email").in("id", ids);
        profMap = Object.fromEntries((profs ?? []).map((p) => [p.id, { username: p.username, email: p.email }]));
      }
      return rows.map((r) => ({ ...r, profiles: profMap[r.user_id] ?? null }));
    },
  });

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    const now = new Date();
    const startToday = new Date(now); startToday.setHours(0, 0, 0, 0);
    const startWeek = new Date(startToday); startWeek.setDate(startToday.getDate() - 6);
    const startMonth = new Date(startToday); startMonth.setDate(1);
    let rows = (data ?? []) as Array<Record<string, unknown> & {
      id: string; gmail: string; user_id: string; status: string; rate: number; created_at: string;
      password_category_name?: string | null; is_valid_prefix?: boolean | null; validation_reason?: string | null;
      profiles?: { username?: string | null; email?: string | null } | null;
    }>;

    if (status === "queue") rows = rows.filter((r) => r.status === "pending" || r.status === "processing");
    else if (status !== "all") rows = rows.filter((r) => r.status === status);

    if (cat !== "all") rows = rows.filter((r) => (r.password_category_name ?? "") === cat);

    if (range !== "all") {
      const cutoff = range === "today" ? startToday : range === "week" ? startWeek : startMonth;
      rows = rows.filter((r) => new Date(r.created_at).getTime() >= cutoff.getTime());
    }

    if (term) {
      rows = rows.filter((r) => {
        return (
          r.gmail?.toLowerCase().includes(term) ||
          r.id.toLowerCase().includes(term) ||
          r.user_id.toLowerCase().includes(term) ||
          (r.profiles?.username ?? "").toLowerCase().includes(term) ||
          (r.profiles?.email ?? "").toLowerCase().includes(term)
        );
      });
    }

    rows = [...rows].sort((a, b) => {
      const t = new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
      return sort === "oldest" ? t : -t;
    });
    return rows;
  }, [data, q, status, range, sort, cat]);

  const review = useMutation({
    mutationFn: async ({
      id, status, user_id, reason,
    }: { id: string; status: SubmissionStatus; user_id: string; reason?: string }) => {
      const now = new Date().toISOString();
      const patch: {
        status: SubmissionStatus;
        reviewed_at: string;
        reviewed_by: string;
        approved_at?: string | null;
        approved_by?: string | null;
        rejected_at?: string | null;
        rejected_by?: string | null;
        rejection_reason?: string | null;
      } = {
        status,
        reviewed_at: now,
        reviewed_by: user!.id,
      };
      if (status === "accepted") { patch.approved_at = now; patch.approved_by = user!.id; }
      if (status === "rejected") {
        patch.rejected_at = now; patch.rejected_by = user!.id;
        if (reason && reason.trim()) patch.rejection_reason = reason.trim();
      }
      if (status === "pending") {
        patch.approved_at = null; patch.approved_by = null;
        patch.rejected_at = null; patch.rejected_by = null;
      }
      const { error } = await supabase.from("submissions").update(patch).eq("id", id);
      if (error) throw error;

      const titles: Record<SubmissionStatus, string> = {
        pending: "Setoran dikembalikan ke antrean",
        processing: "Setoran sedang diproses",
        accepted: "Setoran diterima",
        rejected: "Setoran ditolak",
      };
      const messages: Record<SubmissionStatus, string> = {
        pending: "Setoran Anda kembali ke antrean menunggu.",
        processing: "Setoran Anda sedang direview oleh admin.",
        accepted: "Setoran Anda telah diterima. Saldo akan diperbarui.",
        rejected: reason ? `Setoran Anda ditolak: ${reason}` : "Setoran Anda ditolak.",
      };
      await supabase.from("notifications").insert({
        user_id, category: "submission",
        title: titles[status], message: messages[status],
      });
    },
    onSuccess: (_d, v) => {
      qc.invalidateQueries();
      const label: Record<SubmissionStatus, string> = {
        pending: "Dikembalikan ke antrean",
        processing: "Ditandai sedang diproses",
        accepted: "Diterima",
        rejected: "Ditolak",
      };
      toast.success(label[v.status]);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const [rejectFor, setRejectFor] = useState<{ id: string; user_id: string } | null>(null);
  const [reason, setReason] = useState("");

  return (
    <div>
      <AppTopbar title="Antrean Verifikasi" />
      <div className="mx-auto max-w-6xl p-4 md:p-6">
        <div className="glass mb-4 rounded-3xl p-4 flex flex-col gap-3 md:flex-row md:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Cari Gmail, username, user ID, atau submission ID..."
              className="rounded-full pl-9"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <Select value={status} onValueChange={(v) => setStatus(v as StatusFilter)}>
              <SelectTrigger className="rounded-full w-[150px]"><Filter className="mr-1 h-3.5 w-3.5" /><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="queue">Antrean</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="processing">Diproses</SelectItem>
                <SelectItem value="accepted">Diterima</SelectItem>
                <SelectItem value="rejected">Ditolak</SelectItem>
                <SelectItem value="all">Semua</SelectItem>
              </SelectContent>
            </Select>
            <Select value={range} onValueChange={(v) => setRange(v as RangeFilter)}>
              <SelectTrigger className="rounded-full w-[140px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Sepanjang waktu</SelectItem>
                <SelectItem value="today">Hari ini</SelectItem>
                <SelectItem value="week">7 hari terakhir</SelectItem>
                <SelectItem value="month">Bulan ini</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sort} onValueChange={(v) => setSort(v as "newest" | "oldest")}>
              <SelectTrigger className="rounded-full w-[130px]"><ArrowDownUp className="mr-1 h-3.5 w-3.5" /><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="oldest">Terlama dulu</SelectItem>
                <SelectItem value="newest">Terbaru dulu</SelectItem>
              </SelectContent>
            </Select>
            <Select value={cat} onValueChange={setCat}>
              <SelectTrigger className="rounded-full w-[160px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua kategori</SelectItem>
                {(categories ?? []).map((c) => <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="glass rounded-3xl p-5 overflow-x-auto">
          {isLoading ? <div className="p-6 text-center"><Loader2 className="mx-auto h-6 w-6 animate-spin text-muted-foreground" /></div> : (
            <Table>
              <TableHeader><TableRow>
                <TableHead>Gmail</TableHead><TableHead>Kategori</TableHead><TableHead>Prefix</TableHead><TableHead>User</TableHead><TableHead>Status</TableHead><TableHead>Tarif</TableHead><TableHead>Disetor</TableHead><TableHead className="text-right">Aksi</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {filtered.length === 0 && <TableRow><TableCell colSpan={8} className="py-10 text-center text-sm text-muted-foreground">Tidak ada setoran yang cocok</TableCell></TableRow>}
                {filtered.map((s) => {
                  const st = s.status as SubmissionStatus;
                  const readOnly = st === "accepted" || st === "rejected";
                  return (
                    <TableRow key={s.id}>
                      <TableCell className="font-mono text-xs">{s.gmail}</TableCell>
                      <TableCell className="font-mono text-[11px]">{s.password_category_name ?? "-"}</TableCell>
                      <TableCell><PrefixBadge valid={s.is_valid_prefix} reason={s.validation_reason} /></TableCell>
                      <TableCell className="text-xs">
                        <div className="font-medium truncate max-w-[160px]">{s.profiles?.username ?? "-"}</div>
                        <div className="text-muted-foreground truncate max-w-[160px]">{s.profiles?.email ?? s.user_id.slice(0, 8)}</div>
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={st} />
                      </TableCell>
                      <TableCell>{money(s.rate)}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{dateTime(s.created_at)}</TableCell>
                      <TableCell className="text-right">
                        <div className="inline-flex flex-wrap justify-end gap-2">
                          {readOnly && <span className="text-xs text-muted-foreground">Read only</span>}
                          {st === "pending" && (
                            <Button size="sm" variant="outline" className="rounded-full" disabled={review.isPending}
                              onClick={() => review.mutate({ id: s.id, status: "processing", user_id: s.user_id })}>
                              <PlayCircle className="h-3.5 w-3.5" /> Proses
                            </Button>
                          )}
                          {st === "processing" && (
                            <>
                              <Button size="sm" variant="outline" className="rounded-full" disabled={review.isPending}
                                onClick={() => review.mutate({ id: s.id, status: "pending", user_id: s.user_id })}>
                                <Undo2 className="h-3.5 w-3.5" /> Ke Pending
                              </Button>
                              <Button size="sm" variant="outline" className="rounded-full text-destructive" disabled={review.isPending}
                                onClick={() => { setRejectFor({ id: s.id, user_id: s.user_id }); setReason(""); }}>
                                <X className="h-3.5 w-3.5" /> Tolak
                              </Button>
                              <Button size="sm" className="rounded-full gradient-brand text-white border-0" disabled={review.isPending}
                                onClick={() => review.mutate({ id: s.id, status: "accepted", user_id: s.user_id })}>
                                <Check className="h-3.5 w-3.5" /> Terima
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </div>
      </div>

      <Dialog open={!!rejectFor} onOpenChange={(o) => !o && setRejectFor(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Tolak Setoran</DialogTitle>
            <DialogDescription>Beri alasan penolakan (opsional). Pengguna akan menerima notifikasi.</DialogDescription>
          </DialogHeader>
          <Textarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Contoh: akun sudah tidak aktif" className="rounded-xl" />
          <DialogFooter>
            <Button variant="outline" className="rounded-full" onClick={() => setRejectFor(null)}>Batal</Button>
            <Button
              className="rounded-full bg-destructive text-white border-0 hover:bg-destructive/90"
              disabled={review.isPending}
              onClick={() => {
                if (!rejectFor) return;
                review.mutate(
                  { id: rejectFor.id, status: "rejected", user_id: rejectFor.user_id, reason },
                  { onSettled: () => setRejectFor(null) },
                );
              }}
            >
              Tolak Setoran
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatusBadge({ status }: { status: SubmissionStatus }) {
  const cls: Record<SubmissionStatus, string> = {
    pending: "bg-muted text-muted-foreground",
    processing: "bg-warning/20 text-warning",
    accepted: "bg-success/15 text-success",
    rejected: "bg-destructive/15 text-destructive",
  };
  const label: Record<SubmissionStatus, string> = {
    pending: "Menunggu",
    processing: "🟡 Diproses",
    accepted: "Diterima",
    rejected: "Ditolak",
  };
  return <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${cls[status]}`}>{label[status]}</span>;
}
