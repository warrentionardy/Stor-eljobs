import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";
import { useEffect, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useSettings } from "@/hooks/use-settings";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Save } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/settings")({
  component: SettingsPage,
});

type Schedule = { enabled: boolean; open_time: string; close_time: string; timezone: string };
type ReferralSettings = { enabled: boolean; points_per_approved: number; min_status: string; description: string };

function SettingsPage() {
  const { data: settings, isLoading } = useSettings();
  const [form, setForm] = useState<Record<string, unknown>>({});

  useEffect(() => {
    if (settings) setForm(settings);
  }, [settings]);

  const save = useMutation({
    mutationFn: async () => {
      const rows = Object.entries(form).map(([key, value]) => ({ key, value: value as never }));
      const { error } = await supabase.from("app_settings").upsert(rows, { onConflict: "key" });
      if (error) throw error;
    },
    onSuccess: () => toast.success("Pengaturan disimpan"),
    onError: (e: Error) => toast.error(e.message),
  });

  const get = <T,>(k: string, d: T): T => {
    const v = form[k];
    return (v === undefined || v === null ? d : (v as T));
  };
  const set = (k: string, v: unknown) => setForm((f) => ({ ...f, [k]: v }));

  const schedule = get<Schedule>("storan_schedule", { enabled: false, open_time: "08:00", close_time: "22:00", timezone: "Asia/Jakarta" });
  const referral = get<ReferralSettings>("referral_settings", { enabled: true, points_per_approved: 100, min_status: "accepted", description: "" });

  if (isLoading) {
    return (
      <div>
        <AppTopbar title="Pengaturan Platform" />
        <div className="grid place-items-center py-24"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
      </div>
    );
  }

  return (
    <div>
      <AppTopbar title="Pengaturan Platform" />
      <div className="mx-auto max-w-4xl p-4 md:p-6 space-y-6">

        {/* Site branding */}
        <Section title="Identitas Situs">
          <Field label="Nama Situs">
            <Input value={get("site_name", "")} onChange={(e) => set("site_name", e.target.value)} className="rounded-xl" />
          </Field>
          <Field label="Teks Footer">
            <Input value={get("footer_text", "")} onChange={(e) => set("footer_text", e.target.value)} className="rounded-xl" />
          </Field>
          <Field label="Running Text (Landing)">
            <Input value={get("running_text", "")} onChange={(e) => set("running_text", e.target.value)} className="rounded-xl" />
          </Field>
          <Field label="Banner Landing (URL Gambar)">
            <Input value={get("landing_banner", "")} onChange={(e) => set("landing_banner", e.target.value)} className="rounded-xl" />
          </Field>
          <Field label="Popup Landing (opsional)">
            <Textarea rows={2} value={get("landing_popup", "")} onChange={(e) => set("landing_popup", e.target.value)} className="rounded-xl" />
          </Field>
          <Field label="Link Grup WhatsApp Komunitas">
            <Input value={get("community_whatsapp", "")} onChange={(e) => set("community_whatsapp", e.target.value)} className="rounded-xl" placeholder="https://chat.whatsapp.com/..." />
          </Field>
          <Field label="Link TikTok Resmi">
            <Input value={get("community_tiktok", "")} onChange={(e) => set("community_tiktok", e.target.value)} className="rounded-xl" placeholder="https://www.tiktok.com/@akun" />
          </Field>
        </Section>

        {/* Storan schedule */}
        <Section title="Jadwal Buka/Tutup Storan (Otomatis)">
          <ToggleRow
            title="Aktifkan jadwal otomatis"
            desc="Storan hanya bisa dibuka dalam rentang waktu tertentu."
            checked={!!schedule.enabled}
            onChange={(v) => set("storan_schedule", { ...schedule, enabled: v })}
          />
          <div className="grid gap-3 sm:grid-cols-3">
            <Field label="Jam Buka">
              <Input type="time" value={schedule.open_time} onChange={(e) => set("storan_schedule", { ...schedule, open_time: e.target.value })} className="rounded-xl" />
            </Field>
            <Field label="Jam Tutup">
              <Input type="time" value={schedule.close_time} onChange={(e) => set("storan_schedule", { ...schedule, close_time: e.target.value })} className="rounded-xl" />
            </Field>
            <Field label="Timezone">
              <Input value={schedule.timezone} onChange={(e) => set("storan_schedule", { ...schedule, timezone: e.target.value })} className="rounded-xl" />
            </Field>
          </div>
          <ToggleRow
            title="Override manual: Storan buka"
            desc="Jika override manual aktif, jadwal diabaikan dan status mengikuti nilai ini."
            checked={!!get("storan_enabled", true)}
            onChange={(v) => set("storan_enabled", v)}
          />
          <ToggleRow
            title="Aktifkan Manual Override"
            desc="Saat aktif, scheduler otomatis diabaikan."
            checked={!!get("storan_manual_override", false)}
            onChange={(v) => set("storan_manual_override", v)}
          />
        </Section>

        {/* Referral */}
        <Section title="Pengaturan Referral">
          <ToggleRow
            title="Aktifkan Referral"
            desc="Berikan reward saat Gmail dari referral disetujui."
            checked={!!referral.enabled}
            onChange={(v) => set("referral_settings", { ...referral, enabled: v })}
          />
          <Field label="Reward per Gmail disetujui (poin)">
            <Input
              type="number"
              min={0}
              value={Number(referral.points_per_approved)}
              onChange={(e) => set("referral_settings", { ...referral, points_per_approved: Number(e.target.value) })}
              className="rounded-xl"
            />
          </Field>
          <Field label="Status minimum untuk reward">
            <Input
              value={referral.min_status}
              onChange={(e) => set("referral_settings", { ...referral, min_status: e.target.value })}
              placeholder="accepted"
              className="rounded-xl"
            />
          </Field>
          <Field label="Deskripsi reward">
            <Textarea
              rows={2}
              value={referral.description}
              onChange={(e) => set("referral_settings", { ...referral, description: e.target.value })}
              className="rounded-xl"
            />
          </Field>
        </Section>

        {/* Password & security */}
        <Section title="Keamanan & Password Platform">
          <Field label="Password Platform (untuk seluruh akun setoran)">
            <Input value={get("platform_password", "")} onChange={(e) => set("platform_password", e.target.value)} className="rounded-xl font-mono" />
          </Field>
          <ToggleRow
            title="Registrasi Terbuka"
            desc="Izinkan pengguna baru mendaftar."
            checked={!!get("registration_enabled", true)}
            onChange={(v) => set("registration_enabled", v)}
          />
          <ToggleRow
            title="Login Terbuka"
            desc="Izinkan pengguna login."
            checked={!!get("login_enabled", true)}
            onChange={(v) => set("login_enabled", v)}
          />
          <ToggleRow
            title="Verifikasi Email"
            desc="Wajibkan verifikasi email saat registrasi."
            checked={!!get("email_verification", false)}
            onChange={(v) => set("email_verification", v)}
          />
          <ToggleRow
            title="Mode Maintenance"
            desc="Sembunyikan aplikasi dari pengguna."
            checked={!!get("maintenance_mode", false)}
            onChange={(v) => set("maintenance_mode", v)}
          />
        </Section>

        {/* Withdraw */}
        <Section title="Penarikan (Withdraw)">
          <ToggleRow
            title="Withdraw diaktifkan"
            desc="Pengguna dapat mengajukan penarikan."
            checked={!!get("withdraw_enabled", true)}
            onChange={(v) => set("withdraw_enabled", v)}
          />
          <ToggleRow
            title="Auto-approve penarikan"
            desc="Penarikan langsung diproses tanpa persetujuan manual."
            checked={!!get("withdraw_auto_approve", false)}
            onChange={(v) => set("withdraw_auto_approve", v)}
          />
          <Field label="Withdraw Minimum (Rp)">
            <Input type="number" min={0} value={Number(get("minimum_withdrawal", 0))} onChange={(e) => set("minimum_withdrawal", Number(e.target.value))} className="rounded-xl" />
          </Field>
        </Section>

        {/* Limits */}
        <Section title="Batasan Harian">
          <Field label="Setoran per hari (per pengguna)">
            <Input type="number" min={0} value={Number(get("daily_submission_limit", 100))} onChange={(e) => set("daily_submission_limit", Number(e.target.value))} className="rounded-xl" />
          </Field>
          <Field label="Penarikan per hari (per pengguna)">
            <Input type="number" min={0} value={Number(get("daily_withdraw_limit", 10))} onChange={(e) => set("daily_withdraw_limit", Number(e.target.value))} className="rounded-xl" />
          </Field>
        </Section>

        {/* Announcements */}
        <Section title="Pengumuman Dashboard">
          <Field label="Pengumuman untuk Dashboard Pengguna">
            <Textarea rows={3} value={get("dashboard_announcement", "")} onChange={(e) => set("dashboard_announcement", e.target.value)} className="rounded-xl" />
          </Field>
        </Section>

        {/* Theme */}
        <Section title="Tampilan">
          <Field label="Warna Primer">
            <Input value={get("primary_color", "")} onChange={(e) => set("primary_color", e.target.value)} className="rounded-xl font-mono" />
          </Field>
          <Field label="Warna Sekunder">
            <Input value={get("secondary_color", "")} onChange={(e) => set("secondary_color", e.target.value)} className="rounded-xl font-mono" />
          </Field>
        </Section>

        <div className="sticky bottom-4 z-10 flex justify-end">
          <Button onClick={() => save.mutate()} disabled={save.isPending} className="rounded-full gradient-brand text-white border-0 h-12 px-8 shadow-lg">
            {save.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Save className="mr-1 h-4 w-4" /> Simpan Semua</>}
          </Button>
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="glass rounded-3xl p-6 space-y-4">
      <div className="text-lg font-semibold">{title}</div>
      {children}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function ToggleRow({ title, desc, checked, onChange }: { title: string; desc: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between rounded-2xl bg-accent/40 p-4">
      <div>
        <div className="font-medium text-sm">{title}</div>
        <div className="text-xs text-muted-foreground">{desc}</div>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}
