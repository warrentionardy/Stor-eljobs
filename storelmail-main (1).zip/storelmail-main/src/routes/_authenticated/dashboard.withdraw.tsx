import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { money, dateTime } from "@/lib/format";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useRealtimeInvalidate } from "@/hooks/use-realtime";

export const Route = createFileRoute("/_authenticated/dashboard/withdraw")({
  component: WithdrawPage,
});

const MIN_WITHDRAWAL = 0;
const isValidDana = (v: string) => /^(08|\+628)[0-9]{6,13}$/.test(v.replace(/\s|-/g, ""));

const statusLabel: Record<string, string> = {
  pending: "Menunggu",
  approved: "Disetujui",
  paid: "Dibayar",
  rejected: "Ditolak",
};

function WithdrawPage() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const [amount, setAmount] = useState("");
  const [account_number, setAcct] = useState("");
  const [account_name, setName] = useState("");
  const [confirm, setConfirm] = useState(false);

  useRealtimeInvalidate("withdrawals", [["balance", user!.id], ["withdrawals", user!.id]], `user_id=eq.${user!.id}`);

  const { data: balance } = useQuery({
    queryKey: ["balance", user!.id],
    queryFn: async () => {
      const { data } = await supabase.rpc("get_user_balance", { _user_id: user!.id });
      return data?.[0] ?? { available: 0 };
    },
  });

  const { data: history } = useQuery({
    queryKey: ["withdrawals", user!.id],
    queryFn: async () => {
      const { data } = await supabase.from("withdrawals").select("*").eq("user_id", user!.id).order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const mutate = useMutation({
    mutationFn: async () => {
      const n = Number(amount);
      const { error } = await supabase.from("withdrawals").insert({
        user_id: user!.id, amount: n, payment_method: "DANA",
        account_number: account_number.replace(/\s|-/g, ""), account_name,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Permintaan penarikan berhasil dikirim");
      setAmount(""); setAcct(""); setName(""); setConfirm(false);
      qc.invalidateQueries();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const validate = () => {
    const n = Number(amount);
    if (!n || n <= 0) return "Masukkan jumlah yang valid";
    if (n < MIN_WITHDRAWAL) return `Penarikan minimum ${money(MIN_WITHDRAWAL)}`;
    if (n > Number(balance?.available ?? 0)) return "Jumlah melebihi saldo tersedia";
    if (!account_name.trim()) return "Nama akun wajib diisi";
    if (!isValidDana(account_number)) return "Nomor DANA harus diawali 08 atau +628";
    return null;
  };

  return (
    <div>
      <AppTopbar title="Tarik Saldo" />
      <div className="mx-auto max-w-5xl p-4 md:p-6">
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="glass rounded-3xl p-6 lg:col-span-2">
            <div className="text-lg font-semibold">Ajukan Penarikan</div>
            <div className="mt-1 text-sm text-muted-foreground">Saldo tersedia: <b className="text-foreground">{money(balance?.available)}</b></div>
            <div className="mt-4 inline-flex items-center gap-2 rounded-full bg-brand-accent/10 px-3 py-1 text-xs font-semibold text-brand-accent">
              Metode: DANA
            </div>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <div>
                <Label>Jumlah (Rp)</Label>
                <Input type="number" min={MIN_WITHDRAWAL} step="1000" value={amount} onChange={(e) => setAmount(e.target.value)} className="mt-1 rounded-xl h-11" placeholder="10000" />
              </div>
              <div>
                <Label>Nomor DANA</Label>
                <Input value={account_number} onChange={(e) => setAcct(e.target.value)} className="mt-1 rounded-xl h-11" placeholder="08xxxxxxxxxx" />
              </div>
              <div className="sm:col-span-2">
                <Label>Nama Akun</Label>
                <Input value={account_name} onChange={(e) => setName(e.target.value)} className="mt-1 rounded-xl h-11" placeholder="Nama pemilik DANA" />
              </div>
            </div>
            <div className="mt-5 flex justify-end">
              <Button
                className="rounded-full gradient-brand text-white border-0 h-11 px-6"
                onClick={() => { const e = validate(); if (e) return toast.error(e); setConfirm(true); }}
              >Tinjau &amp; kirim</Button>
            </div>
          </div>

          <div className="glass rounded-3xl p-6">
            <div className="text-sm font-semibold">Ketentuan</div>
            <ul className="mt-2 space-y-2 text-sm text-muted-foreground">
              <li>• Penarikan minimum: {money(MIN_WITHDRAWAL)}</li>
              <li>• Hanya melalui DANA</li>
              <li>• Nomor diawali 08 atau +628</li>
              <li>• Diproses dalam 24 jam</li>
              <li>• Pastikan data akun benar</li>
            </ul>
          </div>
        </div>

        <div className="mt-6 glass rounded-3xl p-5">
          <div className="mb-3 text-sm font-semibold">Riwayat Penarikan</div>
          <div className="overflow-x-auto rounded-2xl border">
            <Table>
              <TableHeader><TableRow>
                <TableHead>Tanggal</TableHead><TableHead>Jumlah</TableHead><TableHead>Nomor DANA</TableHead><TableHead>Nama</TableHead><TableHead>Status</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {(history ?? []).length === 0 && <TableRow><TableCell colSpan={5} className="py-8 text-center text-sm text-muted-foreground">Belum ada penarikan.</TableCell></TableRow>}
                {(history ?? []).map((w) => (
                  <TableRow key={w.id}>
                    <TableCell className="text-xs text-muted-foreground">{dateTime(w.created_at)}</TableCell>
                    <TableCell className="font-semibold">{money(w.amount)}</TableCell>
                    <TableCell className="text-xs">{w.account_number}</TableCell>
                    <TableCell className="text-xs">{w.account_name}</TableCell>
                    <TableCell><span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${w.status === "paid" || w.status === "approved" ? "bg-success/15 text-success" : w.status === "rejected" ? "bg-destructive/15 text-destructive" : "bg-warning/15 text-warning"}`}>{statusLabel[w.status] ?? w.status}</span></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      <Dialog open={confirm} onOpenChange={setConfirm}>
        <DialogContent className="rounded-3xl">
          <DialogHeader>
            <DialogTitle>Konfirmasi penarikan</DialogTitle>
            <DialogDescription>Periksa detail sebelum mengirim permintaan.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 text-sm">
            <Row k="Jumlah" v={money(Number(amount || 0))} />
            <Row k="Metode" v="DANA" />
            <Row k="Nomor DANA" v={account_number} />
            <Row k="Nama" v={account_name} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirm(false)} className="rounded-full">Batal</Button>
            <Button onClick={() => mutate.mutate()} disabled={mutate.isPending} className="rounded-full gradient-brand text-white border-0">
              {mutate.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Konfirmasi penarikan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex justify-between rounded-xl bg-accent/50 px-3 py-2"><span className="text-muted-foreground">{k}</span><span className="font-medium">{v}</span></div>;
}
