import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AppTopbar } from "@/components/app/topbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2, Plus, Pencil, Trash2, ArrowUp, ArrowDown, KeyRound } from "lucide-react";
import { toast } from "sonner";
import { useAllPasswordCategories, type PasswordCategory } from "@/hooks/use-password-categories";

export const Route = createFileRoute("/_authenticated/admin/password-categories")({
  component: PasswordCategoriesAdmin,
});

type Draft = { id?: string; name: string; description: string; is_active: boolean; sort_order: number };

function PasswordCategoriesAdmin() {
  const { data: rows, isLoading } = useAllPasswordCategories();
  const qc = useQueryClient();
  const [draft, setDraft] = useState<Draft | null>(null);

  const invalidate = () => qc.invalidateQueries({ queryKey: ["password_categories"] });

  const save = useMutation({
    mutationFn: async (d: Draft) => {
      const name = d.name.trim();
      if (!name) throw new Error("Nama kategori wajib diisi");
      const payload = {
        name,
        description: d.description.trim(),
        is_active: d.is_active,
        sort_order: Number(d.sort_order) || 0,
      };
      if (d.id) {
        const { error } = await supabase.from("password_categories").update(payload).eq("id", d.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("password_categories").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => { invalidate(); setDraft(null); toast.success("Kategori disimpan"); },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggle = useMutation({
    mutationFn: async ({ id, is_active }: { id: string; is_active: boolean }) => {
      const { error } = await supabase.from("password_categories").update({ is_active }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message),
  });

  const reorder = useMutation({
    mutationFn: async ({ a, b }: { a: PasswordCategory; b: PasswordCategory }) => {
      const { error: e1 } = await supabase.from("password_categories").update({ sort_order: b.sort_order }).eq("id", a.id);
      if (e1) throw e1;
      const { error: e2 } = await supabase.from("password_categories").update({ sort_order: a.sort_order }).eq("id", b.id);
      if (e2) throw e2;
    },
    onSuccess: invalidate,
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("password_categories").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { invalidate(); toast.success("Kategori dihapus"); },
    onError: (e: Error) => toast.error(e.message),
  });

  const list = rows ?? [];

  return (
    <div>
      <AppTopbar title="Password Management" />
      <div className="mx-auto max-w-4xl p-4 md:p-6">
        <div className="glass rounded-3xl p-6">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 text-lg font-semibold">
                <KeyRound className="h-5 w-5 text-brand-accent" /> Kategori Password
              </div>
              <p className="mt-1 text-sm text-muted-foreground">
                Kategori aktif langsung muncul di halaman Storan pengguna secara real-time.
              </p>
            </div>
            <Button
              className="rounded-full gradient-brand text-white border-0"
              onClick={() => setDraft({ name: "", description: "", is_active: true, sort_order: (list.at(-1)?.sort_order ?? 0) + 1 })}
            >
              <Plus className="mr-1 h-4 w-4" /> Tambah Kategori
            </Button>
          </div>

          {isLoading ? (
            <div className="grid place-items-center py-12"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : (
            <div className="overflow-x-auto rounded-2xl border">
              <Table>
                <TableHeader><TableRow>
                  <TableHead>Nama</TableHead>
                  <TableHead>Deskripsi</TableHead>
                  <TableHead>Aktif</TableHead>
                  <TableHead className="text-right">Aksi</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {list.length === 0 && (
                    <TableRow><TableCell colSpan={4} className="py-10 text-center text-sm text-muted-foreground">Belum ada kategori.</TableCell></TableRow>
                  )}
                  {list.map((c, i) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-mono text-sm font-semibold">{c.name}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{c.description || "-"}</TableCell>
                      <TableCell>
                        <Switch checked={c.is_active} onCheckedChange={(v) => toggle.mutate({ id: c.id, is_active: v })} />
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="inline-flex flex-wrap justify-end gap-1">
                          <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full" disabled={i === 0 || reorder.isPending}
                            onClick={() => reorder.mutate({ a: c, b: list[i - 1] })}><ArrowUp className="h-3.5 w-3.5" /></Button>
                          <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full" disabled={i === list.length - 1 || reorder.isPending}
                            onClick={() => reorder.mutate({ a: c, b: list[i + 1] })}><ArrowDown className="h-3.5 w-3.5" /></Button>
                          <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full"
                            onClick={() => setDraft({ id: c.id, name: c.name, description: c.description, is_active: c.is_active, sort_order: c.sort_order })}>
                            <Pencil className="h-3.5 w-3.5" /></Button>
                          <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full text-destructive" disabled={remove.isPending}
                            onClick={() => { if (confirm(`Hapus kategori "${c.name}"?`)) remove.mutate(c.id); }}>
                            <Trash2 className="h-3.5 w-3.5" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      </div>

      <Dialog open={!!draft} onOpenChange={(o) => !o && setDraft(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{draft?.id ? "Edit Kategori" : "Tambah Kategori"}</DialogTitle></DialogHeader>
          {draft && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Nama Kategori</Label>
                <Input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value.toUpperCase() })} placeholder="ELMAILVIP" className="rounded-xl font-mono" />
              </div>
              <div className="space-y-2">
                <Label>Deskripsi (opsional)</Label>
                <Input value={draft.description} onChange={(e) => setDraft({ ...draft, description: e.target.value })} className="rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label>Urutan Tampil</Label>
                <Input type="number" value={draft.sort_order} onChange={(e) => setDraft({ ...draft, sort_order: Number(e.target.value) })} className="rounded-xl" />
              </div>
              <div className="flex items-center justify-between rounded-2xl bg-accent/50 p-3">
                <div className="text-sm font-medium">Aktif</div>
                <Switch checked={draft.is_active} onCheckedChange={(v) => setDraft({ ...draft, is_active: v })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" className="rounded-full" onClick={() => setDraft(null)}>Batal</Button>
            <Button className="rounded-full gradient-brand text-white border-0" disabled={save.isPending}
              onClick={() => draft && save.mutate(draft)}>
              {save.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Simpan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}