import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { dateTime, money } from "@/lib/format";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useRealtimeInvalidate } from "@/hooks/use-realtime";
import { PrefixBadge } from "@/components/app/prefix-badge";

export const Route = createFileRoute("/_authenticated/admin/submissions")({
  component: Page,
});

function Page() {
  useRealtimeInvalidate("submissions", [["admin-submissions"]]);
  const { data } = useQuery({
    queryKey: ["admin-submissions"],
    queryFn: async () => {
      const { data } = await supabase.from("submissions").select("*").order("created_at", { ascending: false }).limit(500);
      return data ?? [];
    },
  });

  return (
    <div>
      <AppTopbar title="Semua Setoran" />
      <div className="mx-auto max-w-6xl p-4 md:p-6">
        <div className="glass rounded-3xl p-5 overflow-x-auto">
          <Table>
            <TableHeader><TableRow>
              <TableHead>Gmail</TableHead><TableHead>Kategori</TableHead><TableHead>Prefix</TableHead><TableHead>Status</TableHead><TableHead>Tarif</TableHead><TableHead>Tanggal</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {(data ?? []).map((s) => (
                <TableRow key={s.id}>
                  <TableCell className="font-mono text-xs">{s.gmail}</TableCell>
                  <TableCell className="font-mono text-[11px]">{s.password_category_name ?? "-"}</TableCell>
                  <TableCell><PrefixBadge valid={s.is_valid_prefix} reason={s.validation_reason} /></TableCell>
                  <TableCell><span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${s.status === "accepted" ? "bg-success/15 text-success" : s.status === "rejected" ? "bg-destructive/15 text-destructive" : s.status === "processing" ? "bg-warning/20 text-warning" : "bg-warning/15 text-warning"}`}>{s.status === "processing" ? "Diproses" : s.status}</span></TableCell>
                  <TableCell>{money(s.rate)}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{dateTime(s.created_at)}</TableCell>
                </TableRow>
              ))}
              {(data ?? []).length === 0 && <TableRow><TableCell colSpan={6} className="py-10 text-center text-sm text-muted-foreground">Belum ada setoran.</TableCell></TableRow>}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
