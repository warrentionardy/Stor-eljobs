import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";

export const Route = createFileRoute("/_authenticated/dashboard/settings")({
  component: Page,
});

function Page() {
  return (
    <div>
      <AppTopbar title="Pengaturan" />
      <div className="mx-auto max-w-3xl p-4 md:p-6">
        <div className="glass rounded-3xl p-6">
          <div className="text-sm font-semibold">Preferensi</div>
          <p className="mt-2 text-sm text-muted-foreground">Tema, notifikasi email, dan lainnya akan segera hadir. Gunakan ikon matahari/bulan di header untuk mengganti tema.</p>
        </div>
      </div>
    </div>
  );
}
