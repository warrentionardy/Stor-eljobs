import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { money, dateTime } from "@/lib/format";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useRealtimeInvalidate } from "@/hooks/use-realtime";

export const Route = createFileRoute("/_authenticated/admin/withdrawals")({
  component: Page,
});

function Page() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  useRealtimeInvalidate("withdrawals", [["admin-withdrawals"]]);


  const { data } = useQuery({
    queryKey: ["admin-withdrawals"],
    queryFn: async () => {
      const { data } = await supabase.from("withdrawals").select("*").order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const update = useMutation({
    mutationFn: async ({ id, status, user_id }: { id: string; status: "approved" | "rejected" | "paid"; user_id: string }) => {
      const { error } = await supabase.from("withdrawals").update({
        status, processed_at: new Date().toISOString(), processed_by: user!.id,
      }).eq("id", id);
      if (error) throw error;
      const label = status === "approved" ? "disetujui" : status === "rejected" ? "ditolak" : "dibayar";
      await supabase.from("notifications").insert({
        user_id, category: "withdrawal",
        title: `Penarikan ${label}`,
        message: `Permintaan penarikan Anda telah ${label}.`,
      });
    },
    onSuccess: () => { qc.invalidateQueries(); toast.success("Diperbarui"); },
    onError: (e: Error) => toast.error(e.message),
  });

  const statusLabel: Record<string, string> = { pending: "Menunggu", approved: "Disetujui", paid: "Dibayar", rejected: "Ditolak" };

  return (
    <div>
      <AppTopbar title="Permintaan Penarikan" />
      <div className="mx-auto max-w-6xl p-4 md:p-6">
        <div className="glass rounded-3xl p-5 overflow-x-auto">
          <Table>
            <TableHeader><TableRow>
              <TableHead>Tanggal</TableHead><TableHead>Jumlah</TableHead><TableHead>Metode</TableHead>
              <TableHead>Nama Akun</TableHead><TableHead>Nomor DANA</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Aksi</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {(data ?? []).map((w) => (
                <TableRow key={w.id}>
                  <TableCell className="text-xs text-muted-foreground">{dateTime(w.created_at)}</TableCell>
                  <TableCell className="font-semibold">{money(w.amount)}</TableCell>
                  <TableCell>{w.payment_method}</TableCell>
                  <TableCell className="text-xs">{w.account_name}</TableCell>
                  <TableCell className="text-xs">{w.account_number}</TableCell>
                  <TableCell><span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${w.status === "paid" || w.status === "approved" ? "bg-success/15 text-success" : w.status === "rejected" ? "bg-destructive/15 text-destructive" : "bg-warning/15 text-warning"}`}>{statusLabel[w.status] ?? w.status}</span></TableCell>
                  <TableCell className="text-right">
                    {w.status === "pending" && (
                      <div className="inline-flex gap-2">
                        <Button size="sm" variant="outline" className="rounded-full text-destructive" onClick={() => update.mutate({ id: w.id, status: "rejected", user_id: w.user_id })}>Tolak</Button>
                        <Button size="sm" variant="outline" className="rounded-full" onClick={() => update.mutate({ id: w.id, status: "approved", user_id: w.user_id })}>Setujui</Button>
                        <Button size="sm" className="rounded-full gradient-brand text-white border-0" onClick={() => update.mutate({ id: w.id, status: "paid", user_id: w.user_id })}>Tandai dibayar</Button>
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {(data ?? []).length === 0 && <TableRow><TableCell colSpan={7} className="py-10 text-center text-sm text-muted-foreground">Belum ada permintaan penarikan.</TableCell></TableRow>}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
