import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AppTopbar } from "@/components/app/topbar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { dateTime, money } from "@/lib/format";
import { Download, Search } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useRealtimeInvalidate } from "@/hooks/use-realtime";
import { PrefixBadge } from "@/components/app/prefix-badge";
import { usePasswordCategories } from "@/hooks/use-password-categories";


export const Route = createFileRoute("/_authenticated/dashboard/history")({
  component: HistoryPage,
});

function HistoryPage() {
  const { user } = Route.useRouteContext();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("all");
  const [cat, setCat] = useState<string>("all");
  const [page, setPage] = useState(0);
  const pageSize = 15;
  useRealtimeInvalidate("submissions", [["history", user!.id]], `user_id=eq.${user!.id}`);
  const { data: categories } = usePasswordCategories();


  const { data, isLoading } = useQuery({
    queryKey: ["history", user!.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("submissions").select("*").eq("user_id", user!.id).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const filtered = useMemo(() => {
    let rows = [...(data ?? [])].sort((a, b) => +new Date(b.created_at) - +new Date(a.created_at));
    if (status !== "all") rows = rows.filter((r) => r.status === status);
    if (cat !== "all") rows = rows.filter((r) => (r.password_category_name ?? "") === cat);
    const term = q.trim().toLowerCase();
    if (term) {
      rows = rows.filter(
        (r) =>
          r.gmail.toLowerCase().includes(term) ||
          r.id.toLowerCase().includes(term) ||
          r.batch_id.toLowerCase().includes(term),
      );
    }
    return rows;
  }, [data, q, status, cat]);

  const pageRows = filtered.slice(page * pageSize, page * pageSize + pageSize);
  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize));

  const exportCsv = () => {
    const rows = [["Gmail", "Password Category", "Prefix Status", "Verification Status", "Reward", "Submission Date"]];
    filtered.forEach((s) =>
      rows.push([
        s.gmail,
        s.password_category_name ?? "-",
        s.is_valid_prefix === false ? "Invalid Prefix" : "Valid Prefix",
        s.status,
        String(s.status === "accepted" ? s.rate : 0),
        new Date(s.created_at).toISOString(),
      ]),
    );
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `elmail-history-${Date.now()}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <AppTopbar title="Riwayat Setoran" />
      <div className="mx-auto max-w-6xl p-4 md:p-6">
        <div className="glass rounded-3xl p-5">
          <div className="flex flex-col justify-between gap-3 md:flex-row md:items-center">
            <div className="relative w-full max-w-sm">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Cari Gmail atau ID setoran..." value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} className="pl-9 rounded-full h-10" />
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Select value={status} onValueChange={(v) => { setStatus(v); setPage(0); }}>
                <SelectTrigger className="rounded-full h-10 w-40"><SelectValue placeholder="Status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua status</SelectItem>
                  <SelectItem value="pending">Menunggu</SelectItem>
                <SelectItem value="processing">Diproses</SelectItem>
                  <SelectItem value="accepted">Diterima</SelectItem>
                  <SelectItem value="rejected">Ditolak</SelectItem>
                </SelectContent>
              </Select>
              <Select value={cat} onValueChange={(v) => { setCat(v); setPage(0); }}>
                <SelectTrigger className="rounded-full h-10 w-44"><SelectValue placeholder="Kategori" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua kategori</SelectItem>
                  {(categories ?? []).map((c) => <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
              <Button variant="outline" onClick={exportCsv} className="rounded-full"><Download className="mr-1 h-4 w-4" /> CSV</Button>
            </div>
          </div>

          <div className="mt-5 overflow-x-auto rounded-2xl border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Gmail</TableHead>
                  <TableHead>Kategori</TableHead>
                  <TableHead>Prefix</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Reward</TableHead>
                  <TableHead>Tanggal</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading && Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}><TableCell colSpan={6}><Skeleton className="h-6 w-full" /></TableCell></TableRow>
                ))}
                {!isLoading && pageRows.map((s) => (
                  <TableRow key={s.id}>
                    <TableCell className="font-mono text-xs">{s.gmail}</TableCell>
                    <TableCell className="font-mono text-[11px]">{s.password_category_name ?? "-"}</TableCell>
                    <TableCell><PrefixBadge valid={s.is_valid_prefix} reason={s.validation_reason} /></TableCell>
                    <TableCell><span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${s.status === "accepted" ? "bg-success/15 text-success" : s.status === "rejected" ? "bg-destructive/15 text-destructive" : s.status === "processing" ? "bg-warning/25 text-warning" : "bg-warning/15 text-warning"}`}>{({pending:"Menunggu",processing:"Diproses",accepted:"Diterima",rejected:"Ditolak"} as Record<string,string>)[s.status] ?? s.status}</span></TableCell>
                    <TableCell className={`text-right font-medium ${s.status === "accepted" ? "text-success" : "text-muted-foreground"}`}>{money(s.status === "accepted" ? s.rate : 0)}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{dateTime(s.created_at)}</TableCell>
                  </TableRow>
                ))}
                {!isLoading && pageRows.length === 0 && (
                  <TableRow><TableCell colSpan={6} className="py-10 text-center text-sm text-muted-foreground">Tidak ada setoran ditemukan.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </div>

          <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
            <div>{filtered.length} setoran</div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled={page === 0} onClick={() => setPage(page - 1)} className="rounded-full">Sebelumnya</Button>
              <div>{page + 1} / {pageCount}</div>
              <Button variant="outline" size="sm" disabled={page + 1 >= pageCount} onClick={() => setPage(page + 1)} className="rounded-full">Berikutnya</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
