import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AppTopbar } from "@/components/app/topbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Loader2, Save, ScrollText, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";
import { useRule, type Rule } from "@/hooks/use-rule";
import { dateTime } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/admin/rules")({
  component: RulesAdmin,
});

function buildExamples(prefix: string): { valid: string[]; invalid: string[] } {
  const p = prefix.trim().toLowerCase();
  if (!p) return { valid: [], invalid: [] };
  const suffixes = ["racing123", "gacor123", "123456", "john99"];
  const otherPrefixes = ["ko", "abc", "xx", "test"];
  const valid = suffixes.map((s) => `${p}${s}@gmail.com`);
  const invalid = [
    `${otherPrefixes[0]}racing123@gmail.com`,
    `abc123@gmail.com`,
    `test${p}@gmail.com`,
    `racing${p}@gmail.com`,
  ];
  return { valid, invalid };
}

function RulesAdmin() {
  const { user } = Route.useRouteContext();
  const { data: rule, isLoading } = useRule();
  const [form, setForm] = useState<Partial<Rule>>({
    is_active: true, prefix: "", price_match: 0, price_no_match: 0, required_password: "", notes: "",
  });
  const [notesTouched, setNotesTouched] = useState(false);

  useEffect(() => {
    if (rule) { setForm(rule); setNotesTouched(true); }
  }, [rule]);

  const prefix = (form.prefix ?? "").trim().toLowerCase();
  const autoNotes = prefix
    ? `Semua Gmail harus diawali dengan prefix "${prefix}".`
    : "Belum ada prefix wajib.";

  // Auto-sync notes with prefix unless admin manually edits
  useEffect(() => {
    if (!notesTouched) return;
    // If notes is empty or looks like our auto note, keep it in sync with prefix
    const current = (form.notes ?? "").trim();
    const looksAuto = current === "" || /^Semua Gmail harus diawali dengan prefix\b/i.test(current) || /^Belum ada prefix wajib\.?$/i.test(current);
    if (looksAuto && current !== autoNotes) {
      setForm((f) => ({ ...f, notes: autoNotes }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prefix]);

  const examples = useMemo(() => buildExamples(prefix), [prefix]);

  const save = useMutation({
    mutationFn: async () => {
      const payload = {
        is_active: !!form.is_active,
        prefix,
        price_match: Number(form.price_match) || 0,
        price_no_match: Number(form.price_no_match) || 0,
        required_password: form.required_password ?? "",
        notes: form.notes ?? "",
        updated_by: user!.id,
      };
      if (rule?.id) {
        const { error } = await supabase.from("rules").update(payload).eq("id", rule.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("rules").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => toast.success("Rules disimpan. Semua pengguna telah diberi notifikasi."),
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div>
      <AppTopbar title="Rules Management" />
      <div className="mx-auto max-w-3xl p-4 md:p-6">
        <div className="glass rounded-3xl p-6">
          <div className="mb-1 flex items-center gap-2 text-lg font-semibold">
            <ScrollText className="h-5 w-5 text-brand-accent" /> Aturan Aktif
          </div>
          <p className="mb-5 text-sm text-muted-foreground">
            Hanya ada satu aturan aktif. Perubahan langsung terlihat oleh semua pengguna secara real-time.
          </p>

          {isLoading ? (
            <div className="grid place-items-center py-12"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : (
            <div className="space-y-5">
              <div className="flex items-center justify-between rounded-2xl bg-accent/50 p-4">
                <div>
                  <div className="font-medium">Status</div>
                  <div className="text-xs text-muted-foreground">{form.is_active ? "Aktif" : "Nonaktif"}</div>
                </div>
                <Switch checked={!!form.is_active} onCheckedChange={(v) => setForm((f) => ({ ...f, is_active: v }))} />
              </div>

              <div className="space-y-2">
                <Label>Prefix Gmail yang Diperlukan</Label>
                <Input value={form.prefix ?? ""} onChange={(e) => setForm((f) => ({ ...f, prefix: e.target.value }))} placeholder="de" className="rounded-xl" />
                <p className="text-xs text-muted-foreground">Hanya Gmail yang <b>diawali</b> dengan prefix ini yang valid.</p>
              </div>

              {prefix && (
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="rounded-2xl bg-success/10 p-3">
                    <div className="mb-2 flex items-center gap-1 text-xs font-semibold text-success"><CheckCircle2 className="h-3.5 w-3.5" /> Contoh Valid</div>
                    <ul className="space-y-1 font-mono text-xs text-success">
                      {examples.valid.map((ex: string) => <li key={ex}>✅ {ex}</li>)}
                    </ul>
                  </div>
                  <div className="rounded-2xl bg-destructive/10 p-3">
                    <div className="mb-2 flex items-center gap-1 text-xs font-semibold text-destructive"><XCircle className="h-3.5 w-3.5" /> Contoh Tidak Valid</div>
                    <ul className="space-y-1 font-mono text-xs text-destructive">
                      {examples.invalid.map((ex: string) => <li key={ex}>❌ {ex}</li>)}
                    </ul>
                  </div>
                </div>
              )}

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Harga jika Prefix Cocok (Rp)</Label>
                  <Input type="number" value={form.price_match ?? 0} onChange={(e) => setForm((f) => ({ ...f, price_match: Number(e.target.value) }))} className="rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label>Harga jika Prefix TIDAK Cocok (Rp)</Label>
                  <Input type="number" value={form.price_no_match ?? 0} onChange={(e) => setForm((f) => ({ ...f, price_no_match: Number(e.target.value) }))} className="rounded-xl" />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Password yang Diperlukan</Label>
                <Input value={form.required_password ?? ""} onChange={(e) => setForm((f) => ({ ...f, required_password: e.target.value }))} placeholder="aass1122" className="rounded-xl" />
              </div>

              <div className="space-y-2">
                <Label>Catatan Admin (otomatis mengikuti prefix)</Label>
                <Textarea rows={3} value={form.notes ?? ""} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} placeholder={autoNotes} className="rounded-xl" />
                <p className="text-xs text-muted-foreground">Kosongkan untuk memakai catatan otomatis: <i>{autoNotes}</i></p>
              </div>

              {rule?.updated_at && (
                <div className="text-xs text-muted-foreground">Terakhir diperbarui: {dateTime(rule.updated_at)}</div>
              )}

              <div className="flex justify-end">
                <Button onClick={() => save.mutate()} disabled={save.isPending} className="rounded-full gradient-brand text-white border-0 h-11 px-6">
                  {save.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Save className="mr-1 h-4 w-4" /> Simpan Aturan</>}
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
