import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/profile")({
  component: ProfilePage,
});

function ProfilePage() {
  const { user } = Route.useRouteContext();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState(user!.email ?? "");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.from("profiles").select("*").eq("id", user!.id).maybeSingle()
      .then(({ data }) => { if (data) { setUsername(data.username ?? ""); setEmail(data.email ?? user!.email ?? ""); } });
  }, [user]);

  const saveProfile = async () => {
    setLoading(true);
    const { error } = await supabase.from("profiles").update({ username, email }).eq("id", user!.id);
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Profil diperbarui");
  };

  const updatePassword = async () => {
    if (password.length < 6) return toast.error("Kata sandi terlalu pendek");
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) return toast.error(error.message);
    setPassword("");
    toast.success("Kata sandi diperbarui");
  };

  return (
    <div>
      <AppTopbar title="Profil" />
      <div className="mx-auto max-w-3xl p-4 md:p-6 space-y-6">
        <div className="glass rounded-3xl p-6">
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16">
              <AvatarFallback className="gradient-brand text-white text-lg font-bold">{(username || email)[0]?.toUpperCase()}</AvatarFallback>
            </Avatar>
            <div>
              <div className="text-lg font-semibold">{username || "Profil Anda"}</div>
              <div className="text-sm text-muted-foreground">{email}</div>
            </div>
          </div>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <div>
              <Label>Nama pengguna</Label>
              <Input value={username} onChange={(e) => setUsername(e.target.value)} className="mt-1 rounded-xl h-11" />
            </div>
            <div>
              <Label>Email</Label>
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 rounded-xl h-11" />
            </div>
          </div>
          <div className="mt-5 flex justify-end">
            <Button onClick={saveProfile} disabled={loading} className="rounded-full gradient-brand text-white border-0">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Simpan perubahan"}
            </Button>
          </div>
        </div>

        <div className="glass rounded-3xl p-6">
          <div className="text-sm font-semibold">Keamanan</div>
          <div className="mt-3 grid gap-4 sm:grid-cols-2">
            <div>
              <Label>Kata sandi baru</Label>
              <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="mt-1 rounded-xl h-11" />
            </div>
          </div>
          <div className="mt-5 flex justify-end">
            <Button variant="outline" onClick={updatePassword} disabled={loading || !password} className="rounded-full">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Perbarui kata sandi"}
            </Button>
          </div>
        </div>

        <div className="glass rounded-3xl p-6">
          <div className="text-sm font-semibold">Sesi aktif</div>
          <div className="mt-3 rounded-2xl bg-accent/50 p-3 text-sm">
            <div className="font-medium">Sesi saat ini</div>
            <div className="text-xs text-muted-foreground">Masuk sebagai {email}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
