import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";
import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { UploadCloud, CheckCircle2, AlertTriangle, Loader2, FileText, KeyRound, ArrowLeft } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { useRule } from "@/hooks/use-rule";
import { useStoranOpen } from "@/hooks/use-storan";
import { usePasswordCategories, type PasswordCategory } from "@/hooks/use-password-categories";
import { RulesPreview } from "@/components/app/rules-preview";
import { PrefixBadge } from "@/components/app/prefix-badge";
import { checkPrefix, normalizePrefix } from "@/lib/prefix";

export const Route = createFileRoute("/_authenticated/dashboard/submit")({
  component: SubmitPage,
});

const EMAIL_RE = /^[a-z0-9._%+-]+@gmail\.com$/i;
const CATEGORY_STORAGE_KEY = "elmail.selected_password_category";

function ClosedBanner() {
  return (
    <div className="glass mb-4 flex items-center gap-3 rounded-3xl border border-destructive/30 bg-destructive/5 p-5 text-destructive">
      <AlertTriangle className="h-5 w-5" />
      <div>
        <div className="font-semibold">Storan Saat Ini Ditutup</div>
        <div className="text-xs opacity-80">
          Storan sedang ditutup. Silakan kembali saat jam operasional dibuka.
        </div>
      </div>
    </div>
  );
}

function SubmitPage() {
  const { user } = Route.useRouteContext();
  const { data: rule } = useRule();
  const { data: storanOpen } = useStoranOpen();
  const { data: categories, isLoading: catLoading } = usePasswordCategories();
  const [category, setCategory] = useState<PasswordCategory | null>(null);
  const [note, setNote] = useState("");
  const [raw, setRaw] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState<{ count: number } | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const qc = useQueryClient();

  const prefix = normalizePrefix(rule?.prefix);
  const closed = storanOpen === false;

  // Restore the previously selected category (persists until submission completes).
  useEffect(() => {
    if (category || !categories?.length) return;
    try {
      const saved = sessionStorage.getItem(CATEGORY_STORAGE_KEY);
      if (!saved) return;
      const match = categories.find((c) => c.id === saved);
      if (match) setCategory(match);
      else sessionStorage.removeItem(CATEGORY_STORAGE_KEY);
    } catch {
      /* storage unavailable */
    }
  }, [categories, category]);

  const selectCategory = (c: PasswordCategory | null) => {
    setCategory(c);
    try {
      if (c) sessionStorage.setItem(CATEGORY_STORAGE_KEY, c.id);
      else sessionStorage.removeItem(CATEGORY_STORAGE_KEY);
    } catch {
      /* storage unavailable */
    }
  };

  const parsed = useMemo(() => {
    const lines = raw.split(/\n+/).map((l) => l.trim()).filter(Boolean);
    const valid: string[] = [];
    const invalid: string[] = [];
    const seen = new Set<string>();
    lines.forEach((l) => {
      // Accept plain email OR email:password (extract email only, ignore password)
      const email = (l.split(/[|:,\t\s]/)[0] ?? "").trim().toLowerCase();
      if (!email || seen.has(email)) return;
      seen.add(email);
      if (EMAIL_RE.test(email)) valid.push(email);
      else invalid.push(email);
    });
    return { valid, invalid };
  }, [raw]);

  // Prefix status is informational only — submissions are never blocked by it.
  const prefixStats = useMemo(() => {
    let ok = 0;
    parsed.valid.forEach((e) => { if (checkPrefix(e, prefix).valid) ok++; });
    return { ok, bad: parsed.valid.length - ok };
  }, [parsed.valid, prefix]);

  const evaluateRate = (email: string) => {
    if (!rule || !rule.is_active) return { rate: 0, matched: false };
    const matched = prefix ? checkPrefix(email, prefix).valid : false;
    const rate = matched ? Number(rule.price_match) : Number(rule.price_no_match);
    return { rate, matched };
  };

  const handleFile = async (file: File) => {
    const text = await file.text();
    setRaw((r) => (r ? r + "\n" : "") + text);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault(); setDragOver(false);
    const f = e.dataTransfer.files?.[0];
    if (f) handleFile(f);
  };

  const submit = async () => {
    if (submitting) return;
    if (!user?.id) return toast.error("Sesi Anda berakhir. Silakan masuk kembali.");
    if (!category) return toast.error("Pilih kategori password terlebih dahulu");
    if (closed) return toast.error("Storan sedang ditutup. Silakan kembali saat jam operasional dibuka.");
    if (parsed.valid.length === 0) return toast.error("Tambahkan minimal satu alamat gmail yang valid");
    if (!rule || !rule.is_active) return toast.error("Belum ada aturan aktif. Silakan coba lagi nanti.");

    setSubmitting(true);
    // Duplicate detection against user's existing submissions
    const { data: existing } = await supabase
      .from("submissions")
      .select("gmail,status")
      .eq("user_id", user!.id)
      .in("gmail", parsed.valid);
    const dup = new Map<string, string>();
    (existing ?? []).forEach((e) => dup.set(e.gmail, e.status));
    const conflicts = parsed.valid.filter((e) => dup.has(e));
    if (conflicts.length) {
      const first = conflicts[0];
      const st = dup.get(first);
      setSubmitting(false);
      return toast.error(
        `${conflicts.length} Gmail sudah pernah disetor (${first} → ${st}). Hapus dari daftar dulu.`,
      );
    }

    const batchId = crypto.randomUUID();
    const rows = parsed.valid.map((email) => {
      const ev = evaluateRate(email);
      const pc = checkPrefix(email, prefix);
      return {
        user_id: user!.id,
        gmail: email,
        batch_id: batchId,
        rate: ev.rate,
        status: "pending" as const,
        notes: note.trim() || (ev.matched ? "Prefix cocok" : "Prefix tidak cocok"),
        password_category_id: category.id,
        password_category_name: category.name,
        is_valid_prefix: pc.valid,
        validation_reason: pc.reason,
      };
    });
    const { error } = await supabase.from("submissions").insert(rows);
    setSubmitting(false);
    if (error) return toast.error(error.message);
    setDone({ count: parsed.valid.length });
    setRaw("");
    setNote("");
    try { sessionStorage.removeItem(CATEGORY_STORAGE_KEY); } catch { /* noop */ }
    qc.invalidateQueries();
    toast.success(`Berhasil menyetor ${parsed.valid.length} akun`);
  };

  // Step 1 — choose a password category (sourced from database, never hardcoded).
  if (!category) {
    return (
      <div>
        <AppTopbar title="Setor Akun" />
        <div className="mx-auto max-w-4xl p-4 md:p-6">
          {closed && <ClosedBanner />}
          <div className="glass rounded-3xl p-6">
            <div className="flex items-center gap-2 text-lg font-semibold">
              <KeyRound className="h-5 w-5 text-brand-accent" /> Pilih Kategori Password
            </div>
            <p className="mt-1 text-sm text-muted-foreground">
              Setiap setoran dikelompokkan berdasarkan kategori password. Pilih satu untuk melanjutkan.
            </p>

            {catLoading ? (
              <div className="grid place-items-center py-12"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
            ) : (categories ?? []).length === 0 ? (
              <div className="mt-6 rounded-2xl border border-dashed p-8 text-center text-sm text-muted-foreground">
                Belum ada kategori aktif. Silakan hubungi admin.
              </div>
            ) : (
              <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {(categories ?? []).map((c) => (
                  <button
                    key={c.id}
                    onClick={() => selectCategory(c)}
                    className="group rounded-2xl border border-border bg-accent/40 p-4 text-left transition hover:border-brand-accent hover:bg-accent/70"
                  >
                    <div className="font-mono text-base font-bold tracking-wide">{c.name}</div>
                    <div className="mt-1 text-xs text-muted-foreground">{c.description || "Kategori setoran"}</div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <AppTopbar title="Setor Akun" />
      <div className="mx-auto max-w-4xl p-4 md:p-6">
        {closed && <ClosedBanner />}

        <div className="glass mb-4 flex flex-wrap items-center justify-between gap-3 rounded-3xl p-5 border border-brand-accent/20">
          <div>
            <div className="text-xs text-muted-foreground">Kategori</div>
            <div className="mt-0.5 font-mono text-lg font-bold tracking-wide">{category.name}</div>
          </div>
          <Button variant="outline" className="rounded-full" onClick={() => selectCategory(null)}>
            <ArrowLeft className="mr-1 h-4 w-4" /> Ganti kategori
          </Button>
        </div>

        <div className="mb-4"><RulesPreview /></div>

        <div className="glass rounded-3xl p-6">
          <div className="text-lg font-semibold">Setor akun Gmail yang memenuhi syarat</div>
          <p className="mt-1 text-sm text-muted-foreground">
            Tempel satu email Gmail per baris. Password tidak perlu ditulis — kategori <b>{category.name}</b> otomatis tersimpan.
            Gmail yang tidak sesuai prefix tetap dapat disetor dan akan ditinjau admin.
          </p>

          <div
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={onDrop}
            className={`mt-5 rounded-2xl border-2 border-dashed p-5 text-center transition ${dragOver ? "border-brand-accent bg-accent/60" : "border-border"}`}
          >
            <UploadCloud className="mx-auto h-8 w-8 text-muted-foreground" />
            <div className="mt-2 text-sm">Seret & lepas file .txt, atau{" "}
              <button disabled={closed} className="font-semibold text-brand-accent hover:underline disabled:opacity-50" onClick={() => inputRef.current?.click()}>telusuri</button>
            </div>
            <input ref={inputRef} type="file" accept=".txt,text/plain" className="hidden" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
          </div>

          <div className="mt-5">
            <Textarea rows={10} value={raw} onChange={(e) => setRaw(e.target.value)} disabled={closed} placeholder="de123@gmail.com&#10;agus123@gmail.com&#10;..." className="rounded-2xl font-mono text-sm" />
          </div>

          <div className="mt-4 space-y-2">
            <div className="text-sm font-medium">Catatan (opsional)</div>
            <Textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} disabled={closed} placeholder="Catatan tambahan untuk admin..." className="rounded-2xl text-sm" />
          </div>

          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            <div className="rounded-2xl bg-accent/60 p-3 text-sm">
              <div className="text-xs text-muted-foreground">Terdeteksi</div>
              <div className="text-lg font-semibold">{parsed.valid.length + parsed.invalid.length}</div>
            </div>
            <div className="rounded-2xl bg-success/10 p-3 text-sm">
              <div className="text-xs text-success">Valid Prefix</div>
              <div className="text-lg font-semibold text-success">{prefixStats.ok}</div>
            </div>
            <div className="rounded-2xl bg-destructive/10 p-3 text-sm">
              <div className="text-xs text-destructive">Invalid Prefix</div>
              <div className="text-lg font-semibold text-destructive">{prefixStats.bad}</div>
            </div>
          </div>

          {parsed.valid.length > 0 && (
            <div className="mt-3 max-h-52 space-y-1.5 overflow-y-auto rounded-2xl border p-3">
              {parsed.valid.map((e) => {
                const pc = checkPrefix(e, prefix);
                return (
                  <div key={e} className="flex items-center justify-between gap-2 text-xs">
                    <span className="min-w-0 truncate font-mono">{e}</span>
                    <PrefixBadge valid={pc.valid} reason={pc.reason} />
                  </div>
                );
              })}
            </div>
          )}

          {parsed.invalid.length > 0 && (
            <div className="mt-3 rounded-2xl border border-destructive/30 bg-destructive/5 p-3 text-xs text-destructive">
              <AlertTriangle className="mr-1 inline h-3.5 w-3.5" /> {parsed.invalid.length} baris bukan alamat @gmail.com yang valid dan akan dilewati.
            </div>
          )}

          <div className="mt-6 flex justify-end">
            <Button disabled={submitting || closed || parsed.valid.length === 0} onClick={submit} className="rounded-full gradient-brand text-white border-0 h-11 px-6">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : closed ? "Storan Ditutup" : <>Setor {parsed.valid.length || ""} akun <FileText className="ml-1 h-4 w-4" /></>}
            </Button>
          </div>

          <AnimatePresence>
            {done && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                className="mt-5 flex items-center gap-3 rounded-2xl bg-success/10 p-4 text-success">
                <CheckCircle2 className="h-5 w-5" />
                <div><b>{done.count}</b> akun disetor dan sedang diproses.</div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
