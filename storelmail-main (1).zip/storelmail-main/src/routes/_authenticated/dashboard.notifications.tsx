import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { dateTime } from "@/lib/format";
import { Bell, CheckCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useRealtimeInvalidate } from "@/hooks/use-realtime";

export const Route = createFileRoute("/_authenticated/dashboard/notifications")({
  component: NotificationsPage,
});

function NotificationsPage() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  useRealtimeInvalidate("notifications", [["notifications", user!.id]], `user_id=eq.${user!.id}`);


  const { data } = useQuery({
    queryKey: ["notifications", user!.id],
    queryFn: async () => {
      const { data } = await supabase.from("notifications").select("*").eq("user_id", user!.id).order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const unread = (data ?? []).filter((n) => !n.read).length;

  const markAll = async () => {
    const { error } = await supabase.from("notifications").update({ read: true }).eq("user_id", user!.id).eq("read", false);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["notifications", user!.id] });
  };

  return (
    <div>
      <AppTopbar title="Notifikasi" />
      <div className="mx-auto max-w-3xl p-4 md:p-6">
        <div className="glass rounded-3xl p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="grid h-10 w-10 place-items-center rounded-2xl bg-brand/15"><Bell className="h-5 w-5 text-brand-accent" /></div>
              <div>
                <div className="text-sm font-semibold">Pusat notifikasi</div>
                <div className="text-xs text-muted-foreground">{unread} belum dibaca</div>
              </div>
            </div>
            <Button variant="outline" onClick={markAll} className="rounded-full"><CheckCheck className="mr-1 h-4 w-4" /> Tandai semua dibaca</Button>
          </div>
          <div className="mt-5 space-y-2">
            {(data ?? []).length === 0 && <div className="rounded-2xl bg-accent/50 p-6 text-center text-sm text-muted-foreground">Belum ada notifikasi.</div>}
            {(data ?? []).map((n) => (
              <div key={n.id} className={`rounded-2xl border p-4 ${n.read ? "bg-card/60" : "bg-brand/5 border-brand/30"}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${categoryClass(n.category)}`}>{({submission:"Setoran",withdrawal:"Penarikan",announcement:"Pengumuman",system:"Sistem"} as Record<string,string>)[n.category] ?? n.category}</span>
                    <div className="text-sm font-semibold">{n.title}</div>
                  </div>
                  <div className="text-xs text-muted-foreground">{dateTime(n.created_at)}</div>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">{n.message}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function categoryClass(c: string) {
  if (c === "submission") return "bg-brand/15 text-brand-accent";
  if (c === "withdrawal") return "bg-success/15 text-success";
  if (c === "announcement") return "bg-warning/15 text-warning";
  return "bg-accent text-muted-foreground";
}
