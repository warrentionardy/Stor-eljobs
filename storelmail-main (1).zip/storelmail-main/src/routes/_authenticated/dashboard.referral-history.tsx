import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { dateTime } from "@/lib/format";
import { useRealtimeInvalidate } from "@/hooks/use-realtime";

export const Route = createFileRoute("/_authenticated/dashboard/referral-history")({
  component: Page,
});

function Page() {
  const { user } = Route.useRouteContext();
  useRealtimeInvalidate("referral_rewards", [["referral-history"]]);

  const { data } = useQuery({
    queryKey: ["referral-history", user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      const { data } = await supabase
        .from("referral_rewards")
        .select("id, points_awarded, created_at, submission_id, referral:referrals!inner(referrer_id, referred_user_id, profiles:profiles!referrals_referred_user_id_fkey(username,email))")
        .eq("referral.referrer_id", user!.id)
        .order("created_at", { ascending: false })
        .limit(200);
      return data ?? [];
    },
  });

  // Fallback fetch without embedded profile if the FK alias doesn't match.
  const { data: fallback } = useQuery({
    queryKey: ["referral-history-fallback", user?.id],
    enabled: !!user?.id && (!data || data.length === 0),
    queryFn: async () => {
      const { data: refs } = await supabase.from("referrals").select("id, referred_user_id").eq("referrer_id", user!.id);
      const ids = (refs ?? []).map((r) => r.id);
      if (ids.length === 0) return [];
      const { data: rews } = await supabase.from("referral_rewards").select("id, points_awarded, created_at, submission_id, referral_id").in("referral_id", ids).order("created_at", { ascending: false });
      const userIds = (refs ?? []).map((r) => r.referred_user_id);
      const { data: profs } = await supabase.from("profiles").select("id, username, email").in("id", userIds);
      const profMap = new Map((profs ?? []).map((p) => [p.id, p]));
      const refMap = new Map((refs ?? []).map((r) => [r.id, r]));
      return (rews ?? []).map((r) => {
        const ref = refMap.get(r.referral_id);
        const prof = ref ? profMap.get(ref.referred_user_id) : undefined;
        return { ...r, username: prof?.username ?? prof?.email ?? "-" };
      });
    },
  });

  const rows = (fallback && fallback.length > 0 ? fallback : []).length > 0 ? fallback! : (data ?? []).map((r) => ({
    id: r.id,
    points_awarded: r.points_awarded,
    created_at: r.created_at,
    submission_id: r.submission_id,
    username: "-",
  }));

  return (
    <div>
      <AppTopbar title="Riwayat Referral" />
      <div className="mx-auto max-w-5xl p-4 md:p-6">
        <div className="glass rounded-3xl p-5 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tanggal</TableHead>
                <TableHead>Pengguna</TableHead>
                <TableHead>Submission ID</TableHead>
                <TableHead>Reward</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell className="text-xs text-muted-foreground">{dateTime(r.created_at)}</TableCell>
                  <TableCell>{r.username}</TableCell>
                  <TableCell className="font-mono text-xs">{r.submission_id.slice(0, 8)}…</TableCell>
                  <TableCell className="font-semibold">+{Number(r.points_awarded)}</TableCell>
                  <TableCell><span className="rounded-full bg-success/15 px-2 py-0.5 text-[10px] font-semibold uppercase text-success">Awarded</span></TableCell>
                </TableRow>
              ))}
              {rows.length === 0 && (
                <TableRow><TableCell colSpan={5} className="py-10 text-center text-sm text-muted-foreground">Belum ada riwayat.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}