import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AppTopbar } from "@/components/app/topbar";
import { motion } from "framer-motion";
import { Users, Send, Clock, CheckCircle2, XCircle, DollarSign, Wallet, TrendingUp, Banknote } from "lucide-react";
import { money, num } from "@/lib/format";
import { useEffect } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  AreaChart, Area, BarChart, Bar, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell, Legend,
} from "recharts";

export const Route = createFileRoute("/_authenticated/admin/")({
  component: AdminHome,
});

const ACCENT = "oklch(0.55 0.22 262)";

function AdminHome() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["admin-stats"],
    queryFn: async () => {
      const [profiles, subs, wd] = await Promise.all([
        supabase.from("profiles").select("id, created_at"),
        supabase.from("submissions").select("id, status, rate, created_at, password_category_name"),
        supabase.from("withdrawals").select("id, amount, status"),
      ]);
      return { profiles: profiles.data ?? [], subs: subs.data ?? [], wd: wd.data ?? [] };
    },
    staleTime: 0,
  });

  useEffect(() => {
    const channel = supabase
      .channel("admin-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "submissions" }, () => qc.invalidateQueries({ queryKey: ["admin-stats"] }))
      .on("postgres_changes", { event: "*", schema: "public", table: "withdrawals" }, () => qc.invalidateQueries({ queryKey: ["admin-stats"] }))
      .on("postgres_changes", { event: "*", schema: "public", table: "profiles" }, () => qc.invalidateQueries({ queryKey: ["admin-stats"] }))
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [qc]);

  const today = new Date(); today.setHours(0, 0, 0, 0);
  const s = data?.subs ?? [];
  const wd = data?.wd ?? [];
  const isToday = (d: string) => new Date(d).getTime() >= today.getTime();

  const stats = {
    users: data?.profiles.length ?? 0,
    today: s.filter((x) => isToday(x.created_at)).length,
    pending: s.filter((x) => x.status === "pending").length,
    accepted: s.filter((x) => x.status === "accepted").length,
    rejected: s.filter((x) => x.status === "rejected").length,
    todayEarnings: s.filter((x) => x.status === "accepted" && isToday(x.created_at)).reduce((a, x) => a + Number(x.rate), 0),
    totalEarnings: s.filter((x) => x.status === "accepted").reduce((a, x) => a + Number(x.rate), 0),
    totalWithdraw: wd.filter((w) => w.status === "paid" || w.status === "approved").reduce((a, w) => a + Number(w.amount), 0),
    withdrawRequests: wd.filter((w) => w.status === "pending").length,
  };

  // Total Pembayaran shares the exact same source as Total Pendapatan:
  // SUM(rate) over all accepted submissions.
  const totalPayment = stats.totalEarnings;

  // Per password-category breakdown, generated from whatever categories exist in data.
  const byCategory = (() => {
    const map = new Map<string, { name: string; total: number; pending: number; accepted: number; rejected: number; payment: number }>();
    s.forEach((x) => {
      const name = x.password_category_name ?? "Tanpa Kategori";
      const row = map.get(name) ?? { name, total: 0, pending: 0, accepted: 0, rejected: 0, payment: 0 };
      row.total++;
      if (x.status === "accepted") { row.accepted++; row.payment += Number(x.rate); }
      else if (x.status === "rejected") row.rejected++;
      else row.pending++;
      map.set(name, row);
    });
    return Array.from(map.values()).sort((a, b) => b.total - a.total);
  })();

  const cards = [
    { l: "Pengguna Terdaftar", v: num(stats.users), icon: Users },
    { l: "Setoran Hari Ini", v: num(stats.today), icon: Send },
    { l: "Menunggu", v: num(stats.pending), icon: Clock },
    { l: "Diterima", v: num(stats.accepted), icon: CheckCircle2 },
    { l: "Ditolak", v: num(stats.rejected), icon: XCircle },
    { l: "Pendapatan Hari Ini", v: money(stats.todayEarnings), icon: TrendingUp },
    { l: "Total Pendapatan", v: money(stats.totalEarnings), icon: DollarSign },
    { l: "Total Pembayaran", v: money(totalPayment), icon: Banknote },
    { l: "Total Penarikan", v: money(stats.totalWithdraw), icon: Wallet },
  ];

  // hourly submissions today
  const hourly = Array.from({ length: 24 }, (_, h) => ({ hour: `${h}:00`, count: 0 }));
  s.filter((x) => isToday(x.created_at)).forEach((x) => { hourly[new Date(x.created_at).getHours()].count++; });

  // daily submissions last 7 days
  const daily: { day: string; count: number }[] = [];
  const start = new Date(); start.setDate(start.getDate() - 6); start.setHours(0, 0, 0, 0);
  for (let i = 0; i < 7; i++) {
    const d = new Date(start); d.setDate(start.getDate() + i);
    daily.push({ day: d.toLocaleDateString("id-ID", { weekday: "short" }), count: 0 });
  }
  s.forEach((x) => {
    const d = new Date(x.created_at); d.setHours(0, 0, 0, 0);
    const idx = Math.floor((d.getTime() - start.getTime()) / 86400000);
    if (idx >= 0 && idx < 7) daily[idx].count++;
  });

  const statusData = [
    { name: "Diterima", value: stats.accepted, color: "oklch(0.7 0.17 155)" },
    { name: "Ditolak", value: stats.rejected, color: "oklch(0.63 0.24 25)" },
    { name: "Menunggu", value: stats.pending, color: "oklch(0.8 0.16 85)" },
  ];

  return (
    <div>
      <AppTopbar title="Dashboard Admin" />
      <div className="mx-auto max-w-7xl space-y-6 p-4 md:p-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map((c, i) => (
            <motion.div key={c.l} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }} className="glass rounded-3xl p-5">
              <div className="flex items-center justify-between">
                <div className="text-xs text-muted-foreground">{c.l}</div>
                <c.icon className="h-4 w-4 text-brand-accent" />
              </div>
              <div className="mt-2 text-2xl font-bold">{c.v}</div>
            </motion.div>
          ))}
        </div>

        <div className="glass rounded-3xl p-5 overflow-x-auto">
          <div className="mb-3 text-sm font-semibold">Statistik per Kategori Password</div>
          <Table>
            <TableHeader><TableRow>
              <TableHead>Kategori</TableHead>
              <TableHead className="text-right">Total Disetor</TableHead>
              <TableHead className="text-right">Pending</TableHead>
              <TableHead className="text-right">Diterima</TableHead>
              <TableHead className="text-right">Ditolak</TableHead>
              <TableHead className="text-right">Total Pembayaran</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {byCategory.length === 0 && (
                <TableRow><TableCell colSpan={6} className="py-8 text-center text-sm text-muted-foreground">Belum ada setoran.</TableCell></TableRow>
              )}
              {byCategory.map((c) => (
                <TableRow key={c.name}>
                  <TableCell className="font-mono text-xs font-semibold">{c.name}</TableCell>
                  <TableCell className="text-right">{num(c.total)}</TableCell>
                  <TableCell className="text-right text-warning">{num(c.pending)}</TableCell>
                  <TableCell className="text-right text-success">{num(c.accepted)}</TableCell>
                  <TableCell className="text-right text-destructive">{num(c.rejected)}</TableCell>
                  <TableCell className="text-right font-semibold">{money(c.payment)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <div className="grid gap-4 lg:grid-cols-3">
          <div className="glass rounded-3xl p-5 lg:col-span-2">
            <div className="mb-3 text-sm font-semibold">Setoran per Jam (hari ini)</div>
            <div className="h-56">
              <ResponsiveContainer>
                <BarChart data={hourly}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.9 0.02 232)" />
                  <XAxis dataKey="hour" stroke="#94a3b8" fontSize={10} interval={2} />
                  <YAxis stroke="#94a3b8" fontSize={11} allowDecimals={false} />
                  <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid oklch(0.9 0.02 232)" }} />
                  <Bar dataKey="count" fill={ACCENT} radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="glass rounded-3xl p-5">
            <div className="mb-3 text-sm font-semibold">Status Setoran</div>
            <div className="h-56">
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={statusData} dataKey="value" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={3}>
                    {statusData.map((e) => <Cell key={e.name} fill={e.color} />)}
                  </Pie>
                  <Legend />
                  <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid oklch(0.9 0.02 232)" }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="glass rounded-3xl p-5">
          <div className="mb-3 flex items-center justify-between">
            <div className="text-sm font-semibold">Setoran Harian — 7 hari terakhir</div>
            <div className="text-xs text-muted-foreground">{stats.withdrawRequests} permintaan penarikan tertunda</div>
          </div>
          <div className="h-64">
            <ResponsiveContainer>
              <AreaChart data={daily}>
                <defs>
                  <linearGradient id="adminArea" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor={ACCENT} stopOpacity={0.35} />
                    <stop offset="100%" stopColor={ACCENT} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.9 0.02 232)" />
                <XAxis dataKey="day" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid oklch(0.9 0.02 232)" }} />
                <Area type="monotone" dataKey="count" stroke={ACCENT} strokeWidth={2.5} fill="url(#adminArea)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
