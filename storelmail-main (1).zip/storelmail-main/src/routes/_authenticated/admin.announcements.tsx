import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";
import { useState } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { dateTime } from "@/lib/format";
import { useRealtimeInvalidate } from "@/hooks/use-realtime";

export const Route = createFileRoute("/_authenticated/admin/announcements")({
  component: Page,
});

function Page() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  useRealtimeInvalidate("announcements", [["announcements"]]);


  const { data } = useQuery({
    queryKey: ["announcements"],
    queryFn: async () => {
      const { data } = await supabase.from("announcements").select("*").order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  const create = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("announcements").insert({ title, message, created_by: user!.id });
      if (error) throw error;
    },
    onSuccess: () => { qc.invalidateQueries(); setTitle(""); setMessage(""); toast.success("Pengumuman diterbitkan"); },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div>
      <AppTopbar title="Pengumuman" />
      <div className="mx-auto max-w-3xl p-4 md:p-6 space-y-6">
        <div className="glass rounded-3xl p-6">
          <div className="text-sm font-semibold">Pengumuman baru</div>
          <div className="mt-3 space-y-3">
            <div><Label>Judul</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} className="mt-1 rounded-xl h-11" /></div>
            <div><Label>Pesan</Label><Textarea rows={4} value={message} onChange={(e) => setMessage(e.target.value)} className="mt-1 rounded-2xl" /></div>
          </div>
          <div className="mt-4 flex justify-end">
            <Button className="rounded-full gradient-brand text-white border-0" disabled={!title || !message || create.isPending} onClick={() => create.mutate()}>Terbitkan pengumuman</Button>
          </div>
        </div>

        <div className="glass rounded-3xl p-6">
          <div className="text-sm font-semibold">Pengumuman terbaru</div>
          <div className="mt-3 space-y-2">
            {(data ?? []).length === 0 && <div className="rounded-2xl bg-accent/50 p-4 text-sm text-muted-foreground">Belum ada pengumuman.</div>}
            {(data ?? []).map((a) => (
              <div key={a.id} className="rounded-2xl border p-4">
                <div className="flex items-center justify-between">
                  <div className="font-semibold">{a.title}</div>
                  <div className="text-xs text-muted-foreground">{dateTime(a.created_at)}</div>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">{a.message}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
