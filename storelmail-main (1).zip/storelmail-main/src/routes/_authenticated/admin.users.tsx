import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";
import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { dateTime } from "@/lib/format";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Search, ArrowUpDown, ShieldOff, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/users")({
  component: UsersPage,
});

type SortKey = "created_at" | "username" | "submissions" | "reject_count";

function UsersPage() {
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<"all" | "active" | "suspended">("all");
  const [role, setRole] = useState<"all" | "admin" | "user">("all");
  const [sortKey, setSortKey] = useState<SortKey>("created_at");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");

  const { data } = useQuery({
    queryKey: ["admin-users"],
    queryFn: async () => {
      const [profiles, subs, roles] = await Promise.all([
        supabase.from("profiles").select("*").order("created_at", { ascending: false }),
        supabase.from("submissions").select("user_id, status"),
        supabase.from("user_roles").select("user_id, role"),
      ]);
      const subCount = new Map<string, number>();
      (subs.data ?? []).forEach((s) => subCount.set(s.user_id, (subCount.get(s.user_id) ?? 0) + 1));
      const roleMap = new Map<string, string>();
      (roles.data ?? []).forEach((r) => roleMap.set(r.user_id, r.role));
      return (profiles.data ?? []).map((p) => ({
        ...p,
        submissions: subCount.get(p.id) ?? 0,
        role: roleMap.get(p.id) ?? "user",
      }));
    },
  });

  // Realtime updates
  useEffect(() => {
    const ch = supabase
      .channel("admin-users-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "profiles" }, () => qc.invalidateQueries({ queryKey: ["admin-users"] }))
      .on("postgres_changes", { event: "*", schema: "public", table: "submissions" }, () => qc.invalidateQueries({ queryKey: ["admin-users"] }))
      .on("postgres_changes", { event: "*", schema: "public", table: "user_roles" }, () => qc.invalidateQueries({ queryKey: ["admin-users"] }))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [qc]);

  const toggleSuspend = useMutation({
    mutationFn: async ({ id, next }: { id: string; next: "active" | "suspended" }) => {
      const { error } = await supabase.from("profiles").update({ status: next }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: (_, v) => toast.success(v.next === "suspended" ? "Pengguna disuspend" : "Pengguna diaktifkan"),
    onError: (e: Error) => toast.error(e.message),
  });

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    let rows = (data ?? []).filter((u) => {
      if (status !== "all" && (u.status ?? "active") !== status) return false;
      if (role !== "all" && u.role !== role) return false;
      if (!term) return true;
      return (
        (u.username ?? "").toLowerCase().includes(term) ||
        (u.email ?? "").toLowerCase().includes(term) ||
        (u.dana_number ?? "").toLowerCase().includes(term)
      );
    });
    rows = [...rows].sort((a, b) => {
      let av: string | number = "";
      let bv: string | number = "";
      switch (sortKey) {
        case "username": av = (a.username ?? "").toLowerCase(); bv = (b.username ?? "").toLowerCase(); break;
        case "submissions": av = a.submissions; bv = b.submissions; break;
        case "reject_count": av = a.reject_count ?? 0; bv = b.reject_count ?? 0; break;
        default: av = a.created_at; bv = b.created_at;
      }
      if (av < bv) return sortDir === "asc" ? -1 : 1;
      if (av > bv) return sortDir === "asc" ? 1 : -1;
      return 0;
    });
    return rows;
  }, [data, q, status, role, sortKey, sortDir]);

  const sortBtn = (k: SortKey, label: string) => (
    <button
      className="inline-flex items-center gap-1 hover:text-foreground"
      onClick={() => {
        if (sortKey === k) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
        else { setSortKey(k); setSortDir("desc"); }
      }}
    >
      {label} <ArrowUpDown className="h-3 w-3" />
    </button>
  );

  return (
    <div>
      <AppTopbar title="Manajemen Pengguna" />
      <div className="mx-auto max-w-6xl p-4 md:p-6">
        <div className="glass rounded-3xl p-5 mb-4">
          <div className="grid gap-3 md:grid-cols-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Cari nama, email, atau nomor DANA..."
                value={q}
                onChange={(e) => setQ(e.target.value)}
                className="pl-9 rounded-xl h-11"
              />
            </div>
            <Select value={status} onValueChange={(v) => setStatus(v as typeof status)}>
              <SelectTrigger className="h-11 rounded-xl"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Status</SelectItem>
                <SelectItem value="active">Aktif</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
              </SelectContent>
            </Select>
            <Select value={role} onValueChange={(v) => setRole(v as typeof role)}>
              <SelectTrigger className="h-11 rounded-xl"><SelectValue placeholder="Peran" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Peran</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="user">User</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="mt-3 text-xs text-muted-foreground">
            Menampilkan {filtered.length} dari {(data ?? []).length} pengguna
          </div>
        </div>

        <div className="glass rounded-3xl p-5 overflow-x-auto">
          <Table>
            <TableHeader><TableRow>
              <TableHead>{sortBtn("username", "Pengguna")}</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Peran</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">{sortBtn("submissions", "Setoran")}</TableHead>
              <TableHead className="text-right">{sortBtn("reject_count", "Reject")}</TableHead>
              <TableHead>{sortBtn("created_at", "Bergabung")}</TableHead>
              <TableHead className="text-right">Aksi</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {filtered.map((u) => {
                const isSuspended = (u.status ?? "active") === "suspended";
                return (
                  <TableRow key={u.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="grid h-8 w-8 place-items-center rounded-full gradient-brand text-white text-xs font-bold">{(u.username || u.email || "?")[0]?.toUpperCase()}</div>
                        <div className="font-medium">{u.username ?? "—"}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">{u.email}</TableCell>
                    <TableCell><span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${u.role === "admin" ? "bg-brand-accent/15 text-brand-accent" : "bg-accent text-muted-foreground"}`}>{u.role}</span></TableCell>
                    <TableCell>
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${isSuspended ? "bg-destructive/15 text-destructive" : "bg-success/15 text-success"}`}>
                        {isSuspended ? "Suspended" : "Aktif"}
                      </span>
                    </TableCell>
                    <TableCell className="text-right font-semibold">{u.submissions}</TableCell>
                    <TableCell className="text-right text-destructive">{u.reject_count ?? 0}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{dateTime(u.created_at)}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        variant={isSuspended ? "outline" : "destructive"}
                        className="rounded-full"
                        disabled={toggleSuspend.isPending}
                        onClick={() => toggleSuspend.mutate({ id: u.id, next: isSuspended ? "active" : "suspended" })}
                      >
                        {isSuspended ? <><ShieldCheck className="mr-1 h-3 w-3" /> Aktifkan</> : <><ShieldOff className="mr-1 h-3 w-3" /> Suspend</>}
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
              {filtered.length === 0 && <TableRow><TableCell colSpan={8} className="py-10 text-center text-sm text-muted-foreground">Tidak ada pengguna cocok.</TableCell></TableRow>}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
