import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AppTopbar } from "@/components/app/topbar";
import { motion } from "framer-motion";
import { Wallet, TrendingUp, Clock, CheckCircle2, XCircle, ListChecks, ArrowRight, DollarSign, Banknote, Users } from "lucide-react";
import { money, num, dateTime } from "@/lib/format";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { AreaChart, Area, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import { useEffect } from "react";
import { RulesPreview } from "@/components/app/rules-preview";

export const Route = createFileRoute("/_authenticated/dashboard/")({
  component: DashboardHome,
});

function DashboardHome() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();

  useEffect(() => {
    const channel = supabase
      .channel("dashboard-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "submissions", filter: `user_id=eq.${user!.id}` }, () => {
        qc.invalidateQueries({ queryKey: ["submissions", user!.id] });
        qc.invalidateQueries({ queryKey: ["balance", user!.id] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "withdrawals", filter: `user_id=eq.${user!.id}` }, () => {
        qc.invalidateQueries({ queryKey: ["balance", user!.id] });
        qc.invalidateQueries({ queryKey: ["withdrawals-paid", user!.id] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "referral_rewards" }, () => {
        qc.invalidateQueries({ queryKey: ["referral-points", user!.id] });
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [qc, user]);


  const { data: balance } = useQuery({
    queryKey: ["balance", user!.id],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_user_balance", { _user_id: user!.id });
      if (error) throw error;
      return data?.[0] ?? { available: 0, pending: 0, lifetime: 0, withdrawn: 0 };
    },
    // Always re-read from the database; never serve a stale cached total.
    staleTime: 0,
    refetchOnWindowFocus: true,
  });

  const { data: subs, isLoading } = useQuery({
    queryKey: ["submissions", user!.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("submissions").select("*").eq("user_id", user!.id).order("created_at", { ascending: false }).limit(200);
      if (error) throw error;
      return data;
    },
  });

  // Total Pembayaran = sum of COMPLETED (paid) withdrawals only.
  const { data: paidTotal } = useQuery({
    queryKey: ["withdrawals-paid", user!.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("withdrawals")
        .select("amount")
        .eq("user_id", user!.id)
        .eq("status", "paid");
      if (error) throw error;
      return (data ?? []).reduce((a, w) => a + Number(w.amount), 0);
    },
    staleTime: 0,
    refetchOnWindowFocus: true,
  });

  // Referral balance = points awarded to this user as referrer.
  const { data: referralPoints } = useQuery({
    queryKey: ["referral-points", user!.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("referral_rewards")
        .select("points_awarded, referrals!inner(referrer_id)")
        .eq("referrals.referrer_id", user!.id);
      if (error) throw error;
      return (data ?? []).reduce((a, r) => a + Number(r.points_awarded), 0);
    },
    staleTime: 0,
  });

  const stats = (subs ?? []).reduce(
    (a, s) => {
      a.total++;
      if (s.status === "accepted") a.accepted++;
      else if (s.status === "rejected") a.rejected++;
      else a.pending++;
      const today = new Date(); today.setHours(0,0,0,0);
      if (s.status === "accepted" && new Date(s.created_at).getTime() >= today.getTime()) a.today += Number(s.rate);
      return a;
    },
    { total: 0, accepted: 0, rejected: 0, pending: 0, today: 0 },
  );

  const chartData = last7Days(subs ?? []);

  // Total Pendapatan and Total Pembayaran share one source of truth:
  // get_user_balance().lifetime = SUM(rate) of all accepted submissions.
  const lifetime = Number(balance?.lifetime ?? 0);

  const cards = [
    { label: "Saldo Saat Ini", value: money(balance?.available), icon: Wallet, tint: "text-brand-accent" },
    { label: "Total Pendapatan", value: money(lifetime), icon: DollarSign, tint: "text-success" },
    { label: "Total Pembayaran", value: money(paidTotal ?? 0), icon: Banknote, tint: "text-success" },
    { label: "Saldo Referral", value: num(referralPoints ?? 0), icon: Users, tint: "text-brand-accent" },
    { label: "Saldo Tertahan", value: money(balance?.pending), icon: Clock, tint: "text-warning" },
    { label: "Total Ditarik", value: money(balance?.withdrawn), icon: Wallet, tint: "text-brand-accent" },
    { label: "Pendapatan Hari Ini", value: money(stats.today), icon: TrendingUp, tint: "text-success" },
    { label: "Menunggu Verifikasi", value: num(stats.pending), icon: Clock, tint: "text-warning" },
    { label: "Akun Diterima", value: num(stats.accepted), icon: CheckCircle2, tint: "text-success" },
    { label: "Akun Ditolak", value: num(stats.rejected), icon: XCircle, tint: "text-destructive" },
    { label: "Total Disetor", value: num(stats.total), icon: ListChecks, tint: "text-brand-accent" },
  ];

  return (
    <div>
      <AppTopbar title="Dashboard" />
      <div className="mx-auto max-w-7xl p-4 md:p-6">
        <div className="mb-6 flex flex-col justify-between gap-3 md:flex-row md:items-center">
          <div>
            <div className="text-2xl font-bold">Selamat datang kembali 👋</div>
            <div className="text-sm text-muted-foreground">Berikut aktivitas akun Anda hari ini.</div>
          </div>
          <Link to="/dashboard/submit">
            <Button className="rounded-full gradient-brand text-white border-0">Setor akun <ArrowRight className="ml-1 h-4 w-4" /></Button>
          </Link>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {cards.map((c, i) => (
            <motion.div key={c.label}
              initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="glass rounded-3xl p-5"
            >
              <div className="flex items-center justify-between">
                <div className="text-xs text-muted-foreground">{c.label}</div>
                <c.icon className={`h-4 w-4 ${c.tint}`} />
              </div>
              <div className="mt-2 text-2xl font-bold">{c.value}</div>
            </motion.div>
          ))}
        </div>

        <div className="mt-6"><RulesPreview /></div>

        <div className="mt-6 grid gap-4 lg:grid-cols-3">

          <div className="glass rounded-3xl p-5 lg:col-span-2">
            <div className="mb-3 flex items-center justify-between">
              <div className="text-sm font-semibold">Setoran — 7 hari terakhir</div>
            </div>
            <div className="h-64">
              <ResponsiveContainer>
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="area" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor="oklch(0.55 0.22 262)" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="oklch(0.55 0.22 262)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.9 0.02 232)" />
                  <XAxis dataKey="day" stroke="#94a3b8" fontSize={11} />
                  <YAxis stroke="#94a3b8" fontSize={11} />
                  <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid oklch(0.9 0.02 232)" }} />
                  <Area type="monotone" dataKey="count" stroke="oklch(0.55 0.22 262)" strokeWidth={2.5} fill="url(#area)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="glass rounded-3xl p-5">
            <div className="mb-3 text-sm font-semibold">Aktivitas terbaru</div>
            <div className="space-y-3">
              {isLoading && Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-10 w-full rounded-xl" />)}
              {!isLoading && (subs ?? []).slice(0, 6).map((s) => (
                <div key={s.id} className="flex items-center justify-between rounded-2xl bg-accent/40 px-3 py-2 text-sm">
                  <div className="min-w-0 truncate">{s.gmail}</div>
                  <div className={`ml-3 shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${statusClass(s.status)}`}>{statusLabel[s.status] ?? s.status}</div>
                </div>
              ))}
              {!isLoading && (subs ?? []).length === 0 && <div className="text-sm text-muted-foreground">Belum ada setoran.</div>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const statusLabel: Record<string,string> = { pending: "Menunggu", accepted: "Diterima", rejected: "Ditolak" };

function statusClass(s: string) {
  if (s === "accepted") return "bg-success/15 text-success";
  if (s === "rejected") return "bg-destructive/15 text-destructive";
  return "bg-warning/15 text-warning";
}

function last7Days(subs: { created_at: string }[]) {
  const days: { day: string; count: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i); d.setHours(0,0,0,0);
    const label = d.toLocaleDateString(undefined, { weekday: "short" });
    days.push({ day: label, count: 0 });
  }
  const start = new Date(); start.setDate(start.getDate() - 6); start.setHours(0,0,0,0);
  subs.forEach((s) => {
    const d = new Date(s.created_at); d.setHours(0,0,0,0);
    const idx = Math.floor((d.getTime() - start.getTime()) / 86400000);
    if (idx >= 0 && idx < 7) days[idx].count++;
  });
  return days;
}

// unused helper kept for tree-shaking safety
void dateTime;
