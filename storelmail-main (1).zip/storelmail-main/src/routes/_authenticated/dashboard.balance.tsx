import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";
import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { money } from "@/lib/format";
import { motion } from "framer-motion";
import { Wallet, Clock, TrendingUp, ArrowDownCircle } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/dashboard/balance")({
  component: BalancePage,
});

function BalancePage() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();

  const { data: balance } = useQuery({
    queryKey: ["balance", user!.id],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_user_balance", { _user_id: user!.id });
      if (error) throw error;
      return data?.[0] ?? { available: 0, pending: 0, lifetime: 0, withdrawn: 0 };
    },
  });

  useEffect(() => {
    const ch = supabase
      .channel(`balance-live-${user!.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "submissions", filter: `user_id=eq.${user!.id}` }, () => qc.invalidateQueries({ queryKey: ["balance", user!.id] }))
      .on("postgres_changes", { event: "*", schema: "public", table: "withdrawals", filter: `user_id=eq.${user!.id}` }, () => qc.invalidateQueries({ queryKey: ["balance", user!.id] }))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [qc, user]);

  const cards = [
    { label: "Saldo Tersedia", value: money(balance?.available), icon: Wallet, tint: "text-brand-accent" },
    { label: "Saldo Tertunda", value: money(balance?.pending), icon: Clock, tint: "text-warning" },
    { label: "Total Pendapatan", value: money(balance?.lifetime), icon: TrendingUp, tint: "text-success" },
    { label: "Total Ditarik", value: money(balance?.withdrawn), icon: ArrowDownCircle, tint: "text-muted-foreground" },
  ];

  return (
    <div>
      <AppTopbar title="Saldo" />
      <div className="mx-auto max-w-6xl p-4 md:p-6">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl p-8 gradient-brand text-white">
          <div className="text-sm uppercase tracking-wide text-white/80">Saldo tersedia</div>
          <div className="mt-2 text-5xl font-bold">{money(balance?.available)}</div>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <Link to="/dashboard/withdraw"><Button className="rounded-full bg-white text-brand-accent hover:bg-white/90">Tarik saldo</Button></Link>
            <Link to="/dashboard/submit"><Button variant="outline" className="rounded-full border-white/40 text-white hover:bg-white/10">Setor akun lagi</Button></Link>
          </div>
        </motion.div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map((c) => (
            <div key={c.label} className="glass rounded-3xl p-5">
              <div className="flex items-center justify-between">
                <div className="text-xs text-muted-foreground">{c.label}</div>
                <c.icon className={`h-4 w-4 ${c.tint}`} />
              </div>
              <div className="mt-2 text-2xl font-bold">{c.value}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
