import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";
import { useSettings, getSetting } from "@/hooks/use-settings";
import { Button } from "@/components/ui/button";
import { MessageCircle, Music2, ExternalLink } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard/community")({
  component: CommunityPage,
});

function CommunityPage() {
  const { data: settings } = useSettings();
  const whatsapp = getSetting<string>(settings, "community_whatsapp", "");
  const tiktok = getSetting<string>(settings, "community_tiktok", "");

  return (
    <div>
      <AppTopbar title="Komunitas" />
      <div className="mx-auto max-w-3xl p-4 md:p-6 space-y-4">
        <div className="text-center space-y-1 py-4">
          <h1 className="text-2xl font-bold">Bergabung dengan Komunitas</h1>
          <p className="text-muted-foreground text-sm">Ikuti update, tips, dan diskusi dari sesama pengguna.</p>
        </div>

        <CommunityCard
          icon={<MessageCircle className="h-7 w-7 text-white" />}
          gradient="from-emerald-500 to-green-600"
          title="Grup WhatsApp"
          desc="Diskusi cepat, pengumuman jadwal storan, dan tanya jawab langsung."
          url={whatsapp}
          cta="Gabung WhatsApp"
        />

        <CommunityCard
          icon={<Music2 className="h-7 w-7 text-white" />}
          gradient="from-pink-500 via-fuchsia-500 to-cyan-500"
          title="TikTok Resmi"
          desc="Tutorial, tips, dan info promosi terbaru dari Storel Maili."
          url={tiktok}
          cta="Ikuti TikTok"
        />
      </div>
    </div>
  );
}

function CommunityCard({
  icon, gradient, title, desc, url, cta,
}: { icon: React.ReactNode; gradient: string; title: string; desc: string; url: string; cta: string }) {
  const disabled = !url;
  return (
    <div className="glass rounded-3xl p-5 flex items-center gap-4">
      <div className={`h-14 w-14 rounded-2xl bg-gradient-to-br ${gradient} grid place-items-center shrink-0 shadow-md`}>
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <div className="font-semibold">{title}</div>
        <div className="text-xs text-muted-foreground line-clamp-2">{desc}</div>
      </div>
      <Button
        asChild={!disabled}
        disabled={disabled}
        className="rounded-full gradient-brand text-white border-0 shrink-0"
      >
        {disabled ? (
          <span>Segera</span>
        ) : (
          <a href={url} target="_blank" rel="noopener noreferrer">
            {cta} <ExternalLink className="ml-1 h-4 w-4" />
          </a>
        )}
      </Button>
    </div>
  );
}