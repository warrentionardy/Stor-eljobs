import { createFileRoute } from "@tanstack/react-router";
import { AppTopbar } from "@/components/app/topbar";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Copy, Share2, Users, CheckCircle2, Sparkles, Loader2, MessageCircle, Send, Facebook } from "lucide-react";
import { toast } from "sonner";
import { useRealtimeInvalidate } from "@/hooks/use-realtime";
import { dateTime } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/dashboard/referral")({
  component: ReferralPage,
});

function ReferralPage() {
  const { user } = Route.useRouteContext();
  useRealtimeInvalidate("referrals", [["my-referral"], ["my-referral-stats"]]);
  useRealtimeInvalidate("referral_rewards", [["my-referral-stats"], ["my-referral-recent"]]);

  const { data: profile, isLoading } = useQuery({
    queryKey: ["my-referral", user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("referral_code, username").eq("id", user!.id).maybeSingle();
      return data;
    },
  });

  const { data: stats } = useQuery({
    queryKey: ["my-referral-stats", user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      const [refs, rewards] = await Promise.all([
        supabase.from("referrals").select("id", { count: "exact", head: true }).eq("referrer_id", user!.id),
        supabase.from("referral_rewards").select("points_awarded, referral:referrals!inner(referrer_id)").eq("referral.referrer_id", user!.id),
      ]);
      const totalPoints = (rewards.data ?? []).reduce((s: number, r: { points_awarded: number }) => s + Number(r.points_awarded), 0);
      return {
        invited: refs.count ?? 0,
        approved: rewards.data?.length ?? 0,
        points: totalPoints,
      };
    },
  });

  const { data: recent } = useQuery({
    queryKey: ["my-referral-recent", user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      const { data } = await supabase
        .from("referral_rewards")
        .select("id, points_awarded, created_at, submission_id, referral:referrals!inner(referrer_id, referred_user_id)")
        .eq("referral.referrer_id", user!.id)
        .order("created_at", { ascending: false })
        .limit(10);
      return data ?? [];
    },
  });

  const code = profile?.referral_code ?? "";
  const link = typeof window !== "undefined" && code ? `${window.location.origin}/auth?mode=register&ref=${code}` : "";

  const message = `💰 Cari penghasilan tambahan?\n\nYuk gabung di ElMail!\nPlatform storan Gmail yang mudah, aman, dan terpercaya.\n\n✅ Gratis Daftar\n💵 Hingga Rp5.000 / Gmail Approved\n\nDaftar menggunakan link referral saya:\n${link}`;

  const copy = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success(`${label} disalin`);
    } catch {
      toast.error("Gagal menyalin");
    }
  };

  const openShare = (url: string) => {
    if (typeof window !== "undefined") window.open(url, "_blank", "noopener,noreferrer");
  };
  const shareWhatsApp = () => openShare(`https://wa.me/?text=${encodeURIComponent(message)}`);
  const shareTelegram = () => openShare(`https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent(message)}`);
  const shareFacebook = () => openShare(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(link)}&quote=${encodeURIComponent(message)}`);

  return (
    <div>
      <AppTopbar title="Referral" />
      <div className="mx-auto max-w-4xl p-4 md:p-6 space-y-5">
        {isLoading ? (
          <div className="grid place-items-center py-16"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
        ) : (
          <>
            <div className="glass rounded-3xl p-6 space-y-4">
              <div className="flex items-center gap-2 text-sm font-semibold"><Sparkles className="h-4 w-4 text-brand-accent" /> Undang teman, dapatkan poin</div>
              <div className="space-y-2">
                <div className="text-xs text-muted-foreground">Kode Referral Anda</div>
                <div className="flex gap-2">
                  <Input readOnly value={code} className="rounded-xl font-mono text-base font-bold tracking-widest" />
                  <Button onClick={() => copy(code, "Kode")} variant="outline" className="rounded-xl"><Copy className="h-4 w-4" /></Button>
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-xs text-muted-foreground">Link Referral</div>
                <div className="flex gap-2">
                  <Input readOnly value={link} className="rounded-xl text-xs" />
                  <Button onClick={() => copy(link, "Link")} variant="outline" className="rounded-xl"><Copy className="h-4 w-4" /></Button>
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-xs text-muted-foreground">Pesan Ajakan</div>
                <div className="rounded-2xl bg-accent/40 p-3 text-xs whitespace-pre-line">{message}</div>
              </div>

              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <Button onClick={shareWhatsApp} className="rounded-full bg-[#25D366] text-white border-0 hover:bg-[#1ebe5d]">
                  <MessageCircle className="mr-1 h-4 w-4" /> WhatsApp
                </Button>
                <Button onClick={shareTelegram} className="rounded-full bg-[#229ED9] text-white border-0 hover:bg-[#1a86bb]">
                  <Send className="mr-1 h-4 w-4" /> Telegram
                </Button>
                <Button onClick={shareFacebook} className="rounded-full bg-[#1877F2] text-white border-0 hover:bg-[#1560c4]">
                  <Facebook className="mr-1 h-4 w-4" /> Facebook
                </Button>
                <Button onClick={() => copy(`${message}`, "Pesan & link")} variant="outline" className="rounded-full">
                  <Share2 className="mr-1 h-4 w-4" /> Copy Message
                </Button>
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              <StatCard icon={<Users className="h-4 w-4" />} label="Total Diundang" value={stats?.invited ?? 0} tone="accent" />
              <StatCard icon={<CheckCircle2 className="h-4 w-4" />} label="Gmail Disetujui" value={stats?.approved ?? 0} tone="success" />
              <StatCard icon={<Sparkles className="h-4 w-4" />} label="Total Poin" value={stats?.points ?? 0} tone="brand" />
            </div>

            <div className="glass rounded-3xl p-5">
              <div className="mb-3 text-sm font-semibold">Aktivitas Referral Terbaru</div>
              <div className="space-y-2">
                {(recent ?? []).map((r) => (
                  <div key={r.id} className="flex items-center justify-between rounded-2xl bg-accent/40 p-3 text-sm">
                    <div>
                      <div className="font-medium">+{Number(r.points_awarded)} poin</div>
                      <div className="text-xs text-muted-foreground">{dateTime(r.created_at)}</div>
                    </div>
                    <div className="text-xs font-mono text-muted-foreground truncate max-w-[40%]">{r.submission_id.slice(0, 8)}</div>
                  </div>
                ))}
                {(recent ?? []).length === 0 && (
                  <div className="rounded-2xl bg-accent/30 p-6 text-center text-sm text-muted-foreground">Belum ada aktivitas. Bagikan link Anda untuk mulai.</div>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number; tone: "accent" | "success" | "brand" }) {
  const tones = {
    accent: "bg-accent/50 text-foreground",
    success: "bg-success/10 text-success",
    brand: "bg-brand-accent/10 text-brand-accent",
  } as const;
  return (
    <div className={`glass rounded-3xl p-4 ${tones[tone]}`}>
      <div className="flex items-center gap-2 text-xs opacity-80">{icon}{label}</div>
      <div className="mt-2 text-2xl font-bold">{value}</div>
    </div>
  );
}