import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/site/logo";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  component: ResetPassword,
});

function ResetPassword() {
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Kata sandi diperbarui");
    navigate({ to: "/dashboard" });
  };

  return (
    <div className="relative min-h-screen">
      <div className="absolute left-6 top-6"><Logo /></div>
      <div className="mx-auto grid min-h-screen max-w-6xl place-items-center px-4">
        <div className="glass w-full max-w-md rounded-3xl p-7 shadow-soft">
          <h1 className="text-2xl font-bold">Atur kata sandi baru</h1>
          <p className="mt-1 text-sm text-muted-foreground">Pilih kata sandi baru yang kuat untuk mengamankan akun Anda.</p>
          <form onSubmit={submit} className="mt-5 space-y-4">
            <div>
              <Label>Kata sandi baru</Label>
              <div className="relative mt-1">
                <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input required minLength={6} type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="pl-9 h-11 rounded-xl" />
              </div>
            </div>
            <Button disabled={loading} className="w-full rounded-full gradient-brand text-white border-0 h-11">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Perbarui kata sandi"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
