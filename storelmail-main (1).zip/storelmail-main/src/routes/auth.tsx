import { createFileRoute, Link, useNavigate, useSearch } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Loader2, Mail, Lock, User as UserIcon, ArrowRight, Gift } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/site/logo";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";

const searchSchema = z.object({
  mode: z.enum(["login", "register"]).optional(),
  redirect: z.string().optional(),
  ref: z.string().optional(),
});

export const Route = createFileRoute("/auth")({
  validateSearch: (s) => searchSchema.parse(s),
  component: AuthPage,
});

function AuthPage() {
  const { mode: initialMode, redirect, ref } = useSearch({ from: "/auth" });
  const [mode, setMode] = useState<"login" | "register">(initialMode ?? "login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [refCode, setRefCode] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (ref) {
      setRefCode(ref.toUpperCase());
      setMode("register");
    }
  }, [ref]);

  const go = () => navigate({ to: redirect ?? "/dashboard" });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "register") {
        const meta: Record<string, string> = { username };
        if (refCode.trim()) meta.referral_code = refCode.trim().toUpperCase();
        const { error } = await supabase.auth.signUp({
          email, password,
          options: {
            emailRedirectTo: `${window.location.origin}/dashboard`,
            data: meta,
          },
        });
        if (error) throw error;
        toast.success("Akun berhasil dibuat! Anda telah masuk.");
        go();
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Selamat datang kembali!");
        go();
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Terjadi kesalahan");
    } finally {
      setLoading(false);
    }
  };

  const google = async () => {
    setLoading(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      toast.error(result.error.message ?? "Masuk dengan Google gagal");
      setLoading(false);
      return;
    }
    if (result.redirected) return;
    toast.success("Berhasil masuk dengan Google");
    go();
  };

  return (
    <div className="relative min-h-screen">
      <div className="absolute left-6 top-6"><Logo /></div>

      <div className="mx-auto grid min-h-screen max-w-6xl place-items-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="glass w-full max-w-md rounded-3xl p-7 shadow-soft"
        >
          <div className="mb-6 text-center">
            <h1 className="text-2xl font-bold">{mode === "login" ? "Selamat datang kembali" : "Buat akun Anda"}</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {mode === "login" ? "Masuk ke dashboard ElMail Anda" : "Mulai menghasilkan dalam hitungan menit"}
            </p>
          </div>

          <Button type="button" variant="outline" onClick={google} disabled={loading} className="w-full rounded-full h-11">
            <GoogleIcon /> Lanjutkan dengan Google
          </Button>

          <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground">
            <div className="h-px flex-1 bg-border" /> atau <div className="h-px flex-1 bg-border" />
          </div>

          <form onSubmit={submit} className="space-y-3">
            {mode === "register" && (
              <>
                <div>
                  <Label>Nama pengguna</Label>
                  <div className="relative mt-1">
                    <UserIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input required value={username} onChange={(e) => setUsername(e.target.value)} placeholder="namaanda" className="pl-9 h-11 rounded-xl" />
                  </div>
                </div>
                <div>
                  <Label>Kode Referral <span className="text-muted-foreground">(opsional)</span></Label>
                  <div className="relative mt-1">
                    <Gift className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input value={refCode} onChange={(e) => setRefCode(e.target.value.toUpperCase())} placeholder="ELMXXXX" className="pl-9 h-11 rounded-xl font-mono tracking-widest" />
                  </div>
                </div>
              </>
            )}
            <div>
              <Label>Email</Label>
              <div className="relative mt-1">
                <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" className="pl-9 h-11 rounded-xl" />
              </div>
            </div>
            <div>
              <div className="flex justify-between">
                <Label>Kata sandi</Label>
                {mode === "login" && (
                  <Link to="/forgot-password" className="text-xs text-brand-accent hover:underline">Lupa?</Link>
                )}
              </div>
              <div className="relative mt-1">
                <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input required type="password" minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" className="pl-9 h-11 rounded-xl" />
              </div>
            </div>

            <Button disabled={loading} className="w-full rounded-full gradient-brand text-white border-0 h-11 mt-2">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <>{mode === "login" ? "Masuk" : "Buat akun"} <ArrowRight className="ml-1 h-4 w-4" /></>}
            </Button>
          </form>

          <div className="mt-5 text-center text-sm text-muted-foreground">
            {mode === "login" ? (
              <>Baru di ElMail?{" "}
                <button type="button" className="font-medium text-brand-accent hover:underline" onClick={() => setMode("register")}>Buat akun</button>
              </>
            ) : (
              <>Sudah punya akun?{" "}
                <button type="button" className="font-medium text-brand-accent hover:underline" onClick={() => setMode("login")}>Masuk</button>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.75h3.57c2.08-1.92 3.28-4.74 3.28-8.07z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.75c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.12c-.22-.66-.35-1.36-.35-2.12s.13-1.46.35-2.12V7.04H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.96l3.66-2.84z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.04l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z" />
    </svg>
  );
}
