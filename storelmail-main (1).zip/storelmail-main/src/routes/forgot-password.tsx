import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Loader2, Mail, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/site/logo";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/forgot-password")({
  component: ForgotPassword,
});

function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setLoading(false);
    if (error) return toast.error(error.message);
    setSent(true);
    toast.success("Email reset terkirim");
  };

  return (
    <div className="relative min-h-screen">
      <div className="absolute left-6 top-6"><Logo /></div>
      <div className="mx-auto grid min-h-screen max-w-6xl place-items-center px-4">
        <div className="glass w-full max-w-md rounded-3xl p-7 shadow-soft">
          <Link to="/auth" className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-3.5 w-3.5" /> Kembali ke halaman masuk
          </Link>
          <h1 className="mt-4 text-2xl font-bold">Atur ulang kata sandi</h1>
          <p className="mt-1 text-sm text-muted-foreground">Kami akan mengirim tautan untuk mengatur ulang kata sandi Anda.</p>
          {sent ? (
            <div className="mt-6 rounded-2xl bg-success/10 p-4 text-sm text-success">
              Periksa kotak masuk — tautan reset sedang dikirim ke <b>{email}</b>.
            </div>
          ) : (
            <form onSubmit={submit} className="mt-5 space-y-4">
              <div>
                <Label>Email</Label>
                <div className="relative mt-1">
                  <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="pl-9 h-11 rounded-xl" />
                </div>
              </div>
              <Button disabled={loading} className="w-full rounded-full gradient-brand text-white border-0 h-11">
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Kirim tautan reset"}
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
