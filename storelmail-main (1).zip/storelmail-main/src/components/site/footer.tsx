import { Logo } from "./logo";
import { Github, Twitter, Linkedin } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-border/60">
      <div className="mx-auto max-w-6xl px-4 py-14">
        <div className="grid gap-10 md:grid-cols-5">
          <div className="md:col-span-2">
            <Logo />
            <p className="mt-3 max-w-sm text-sm text-muted-foreground">
              Platform untuk menyetor akun email yang memenuhi syarat dan dibayar dengan cepat serta aman.
            </p>
            <div className="mt-4 flex gap-2">
              <a className="grid h-9 w-9 place-items-center rounded-full border hover:bg-accent" href="#"><Twitter className="h-4 w-4" /></a>
              <a className="grid h-9 w-9 place-items-center rounded-full border hover:bg-accent" href="#"><Github className="h-4 w-4" /></a>
              <a className="grid h-9 w-9 place-items-center rounded-full border hover:bg-accent" href="#"><Linkedin className="h-4 w-4" /></a>
            </div>
          </div>
          {[
            { title: "Tentang", items: ["Perusahaan", "Karier", "Blog"] },
            { title: "Sumber Daya", items: ["Dokumen", "Bantuan", "Status"] },
            { title: "Legal", items: ["Ketentuan", "Kebijakan Privasi", "Kontak"] },
          ].map((c) => (
            <div key={c.title}>
              <div className="text-sm font-semibold">{c.title}</div>
              <ul className="mt-3 space-y-2">
                {c.items.map((i) => (
                  <li key={i}><a href="#" className="text-sm text-muted-foreground hover:text-foreground">{i}</a></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-10 flex flex-col items-center justify-between gap-2 border-t pt-6 text-xs text-muted-foreground md:flex-row">
          <div>© {new Date().getFullYear()} ElMail. Semua hak dilindungi.</div>
          <div>Dibuat dengan sepenuh hati.</div>
        </div>
      </div>
    </footer>
  );
}
