import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, X, Moon, Sun } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Logo } from "./logo";
import { Button } from "@/components/ui/button";

const links = [
  { href: "#home", label: "Beranda" },
  { href: "#features", label: "Fitur" },
  { href: "#how", label: "Cara Kerja" },
  { href: "#rules", label: "Rules Hari Ini" },
  { href: "#faq", label: "FAQ" },
];

export function SiteNav() {
  const [open, setOpen] = useState(false);
  const [dark, setDark] = useState(false);

  useEffect(() => {
    setDark(document.documentElement.classList.contains("dark"));
  }, []);

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("elmail-theme", next ? "dark" : "light");
  };

  return (
    <header className="sticky top-0 z-50 w-full">
      <div className="mx-auto mt-3 max-w-6xl px-4">
        <nav className="glass flex items-center justify-between rounded-3xl px-4 py-2.5 shadow-sm">
          <Logo />
          <ul className="hidden items-center gap-1 md:flex">
            {links.map((l) => (
              <li key={l.href}>
                <a href={l.href} className="rounded-full px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-accent hover:text-foreground transition">
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
          <div className="flex items-center gap-2">
            <button aria-label="Toggle theme" onClick={toggleTheme} className="hidden h-9 w-9 items-center justify-center rounded-full border md:inline-flex">
              {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
            <Link to="/auth" className="hidden md:inline-flex">
              <Button variant="ghost" className="rounded-full">Masuk</Button>
            </Link>
            <Link to="/auth" search={{ mode: "register" } as never} className="hidden md:inline-flex">
              <Button className="rounded-full gradient-brand text-white shadow-soft border-0">Daftar</Button>
            </Link>
            <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Menu">
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </nav>
        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className="glass mt-2 rounded-2xl p-3 md:hidden"
            >
              <ul className="flex flex-col gap-1">
                {links.map((l) => (
                  <li key={l.href}>
                    <a href={l.href} onClick={() => setOpen(false)} className="block rounded-xl px-3 py-2 text-sm hover:bg-accent">{l.label}</a>
                  </li>
                ))}
                <li className="mt-2 flex gap-2">
                  <Link to="/auth" className="flex-1"><Button variant="outline" className="w-full rounded-full">Masuk</Button></Link>
                  <Link to="/auth" search={{ mode: "register" } as never} className="flex-1"><Button className="w-full rounded-full gradient-brand text-white border-0">Daftar</Button></Link>
                </li>
              </ul>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}
