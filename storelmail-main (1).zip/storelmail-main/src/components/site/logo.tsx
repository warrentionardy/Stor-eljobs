import { Link } from "@tanstack/react-router";
import { Mail } from "lucide-react";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link to="/" className={`inline-flex items-center gap-2 ${className}`}>
      <span className="grid h-9 w-9 place-items-center rounded-2xl gradient-brand shadow-soft">
        <Mail className="h-5 w-5 text-white" />
      </span>
      <span className="text-lg font-bold tracking-tight">
        El<span className="gradient-text">Mail</span>
      </span>
    </Link>
  );
}
