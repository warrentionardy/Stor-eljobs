import { motion } from "framer-motion";
import { UserPlus, LogIn, Send, ShieldCheck, TrendingUp, Wallet } from "lucide-react";
import { SectionHeader } from "./features";

const steps = [
  { icon: UserPlus, title: "Daftar", body: "Buat akun ElMail gratis dalam hitungan detik." },
  { icon: LogIn, title: "Masuk", body: "Akses dashboard dan pengaturan Anda yang aman." },
  { icon: Send, title: "Setor Akun", body: "Tempel atau unggah akun Gmail yang memenuhi syarat untuk ditinjau." },
  { icon: ShieldCheck, title: "Verifikasi", body: "Tim kami memverifikasi setiap setoran dengan teliti." },
  { icon: TrendingUp, title: "Saldo Diperbarui", body: "Akun yang disetujui langsung menambah saldo Anda." },
  { icon: Wallet, title: "Tarik Saldo", body: "Ajukan pencairan melalui DANA." },
];

export function HowItWorks() {
  return (
    <section id="how" className="mx-auto mt-32 max-w-6xl px-4">
      <SectionHeader eyebrow="Cara kerja" title="Dari daftar hingga pencairan dalam enam langkah" />
      <div className="relative mt-12">
        <div className="absolute left-1/2 top-0 hidden h-full w-px -translate-x-1/2 bg-border md:block" />
        <ol className="space-y-6 md:space-y-10">
          {steps.map((s, i) => {
            const left = i % 2 === 0;
            return (
              <motion.li
                key={s.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.05 }}
                className="grid items-center gap-4 md:grid-cols-2"
              >
                <div className={left ? "md:pr-10 md:text-right md:order-1" : "md:pl-10 md:order-2"}>
                  <div className="glass inline-block rounded-2xl p-5">
                    <div className="text-xs font-semibold text-brand-accent">Step {i + 1}</div>
                    <div className="mt-1 text-lg font-semibold">{s.title}</div>
                    <p className="mt-1 text-sm text-muted-foreground">{s.body}</p>
                  </div>
                </div>
                <div className={left ? "md:order-2 md:pl-10" : "md:order-1 md:pr-10 md:flex md:justify-end"}>
                  <div className="grid h-14 w-14 place-items-center rounded-2xl gradient-brand text-white shadow-soft">
                    <s.icon className="h-6 w-6" />
                  </div>
                </div>
              </motion.li>
            );
          })}
        </ol>
      </div>
    </section>
  );
}
