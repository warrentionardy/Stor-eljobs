import { motion } from "framer-motion";
import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export function CTA() {
  return (
    <section className="mx-auto mt-32 max-w-6xl px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="relative overflow-hidden rounded-3xl gradient-brand p-10 text-center text-white shadow-soft md:p-16"
      >
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "radial-gradient(600px 200px at 20% 0%, white, transparent)" }} />
        <h2 className="relative text-3xl font-bold md:text-5xl">Mulai hasilkan uang dengan ElMail hari ini</h2>
        <p className="relative mx-auto mt-3 max-w-xl text-white/90">Bergabung dengan ribuan kontributor yang sudah menggunakan ElMail untuk menyetor akun dan dibayar cepat.</p>
        <div className="relative mt-8 flex justify-center gap-3">
          <Link to="/auth">
            <Button size="lg" className="rounded-full bg-white text-brand-accent hover:bg-white/90 h-12 px-6">
              Buat akun gratis <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </motion.div>
    </section>
  );
}
