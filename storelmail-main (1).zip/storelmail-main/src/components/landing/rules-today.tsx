import { motion } from "framer-motion";
import { Check, X, KeyRound, Tag, Clock, Info } from "lucide-react";
import { SectionHeader } from "./features";
import { useRule } from "@/hooks/use-rule";
import { money, dateTime } from "@/lib/format";

export function RulesToday() {
  const { data: rule, isLoading } = useRule();

  return (
    <section id="rules" className="mx-auto mt-32 max-w-5xl px-4">
      <SectionHeader eyebrow="Rules Hari Ini" title="Aturan setoran terkini" desc="Data diperbarui langsung oleh admin secara real-time. Ikuti prefix dan password hari ini untuk mendapatkan harga terbaik." />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="mt-10 rounded-3xl glass p-6 md:p-8"
      >
        {isLoading ? (
          <div className="py-8 text-center text-sm text-muted-foreground">Memuat aturan...</div>
        ) : !rule ? (
          <div className="py-8 text-center text-sm text-muted-foreground">Belum ada aturan aktif.</div>
        ) : (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <div className="text-sm font-semibold">Status</div>
              <span className={`rounded-full px-3 py-1 text-xs font-bold uppercase ${rule.is_active ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"}`}>
                {rule.is_active ? "Aktif" : "Nonaktif"}
              </span>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <RuleItem icon={Tag} label="Prefix diperlukan" value={rule.prefix || "-"} />
              <RuleItem icon={KeyRound} label="Password diperlukan" value={rule.required_password || "-"} mono />
              <RuleItem icon={Check} tint="text-success" label="Harga jika prefix cocok" value={money(rule.price_match)} />
              <RuleItem icon={X} tint="text-warning" label="Harga jika prefix tidak cocok" value={money(rule.price_no_match)} />
            </div>

            {rule.notes && (
              <div className="flex items-start gap-2 rounded-2xl border border-brand-accent/20 bg-brand-accent/5 p-4 text-sm">
                <Info className="mt-0.5 h-4 w-4 shrink-0 text-brand-accent" />
                <div><span className="font-semibold">Catatan Admin: </span>{rule.notes}</div>
              </div>
            )}

            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Clock className="h-3.5 w-3.5" /> Terakhir diperbarui: {dateTime(rule.updated_at)}
            </div>
          </div>
        )}
      </motion.div>
    </section>
  );
}

function RuleItem({ icon: Icon, label, value, tint, mono }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; tint?: string; mono?: boolean }) {
  return (
    <div className="rounded-2xl bg-accent/50 p-4">
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Icon className={`h-3.5 w-3.5 ${tint ?? "text-brand-accent"}`} /> {label}
      </div>
      <div className={`mt-1 text-lg font-bold ${tint ?? ""} ${mono ? "font-mono" : ""}`}>{value}</div>
    </div>
  );
}
