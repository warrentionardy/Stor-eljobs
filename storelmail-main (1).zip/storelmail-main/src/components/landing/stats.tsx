import { motion, useInView, useMotionValue, animate } from "framer-motion";
import { useEffect, useRef } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

function Counter({ to, prefix = "", suffix = "" }: { to: number; prefix?: string; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const mv = useMotionValue(0);
  const inView = useInView(ref, { once: false, margin: "-40px" });
  useEffect(() => {
    if (!inView) return;
    const controls = animate(mv, to, {
      duration: 1.4, ease: "easeOut",
      onUpdate: (v: number) => { if (ref.current) ref.current.textContent = prefix + Math.floor(v).toLocaleString("id-ID") + suffix; }
    });
    return () => controls.stop();
  }, [inView, to, prefix, suffix, mv]);
  return <span ref={ref}>{prefix}0{suffix}</span>;
}

async function fetchLandingStats() {
  const [users, subs, accepted, paid] = await Promise.all([
    supabase.from("profiles").select("id", { count: "exact", head: true }),
    supabase.from("submissions").select("id", { count: "exact", head: true }),
    supabase.from("submissions").select("id", { count: "exact", head: true }).eq("status", "accepted"),
    supabase.from("withdrawals").select("amount").eq("status", "paid"),
  ]);
  const totalPaid = (paid.data ?? []).reduce((sum, w) => sum + Number(w.amount ?? 0), 0);
  return {
    users: users.count ?? 0,
    submissions: subs.count ?? 0,
    accepted: accepted.count ?? 0,
    totalPaid,
  };
}

export function Stats() {
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: ["landing-stats"], queryFn: fetchLandingStats, refetchInterval: 30000 });

  useEffect(() => {
    const ch = supabase
      .channel("landing-stats-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "profiles" }, () => qc.invalidateQueries({ queryKey: ["landing-stats"] }))
      .on("postgres_changes", { event: "*", schema: "public", table: "submissions" }, () => qc.invalidateQueries({ queryKey: ["landing-stats"] }))
      .on("postgres_changes", { event: "*", schema: "public", table: "withdrawals" }, () => qc.invalidateQueries({ queryKey: ["landing-stats"] }))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [qc]);

  const stats = [
    { label: "Pengguna Terdaftar", value: data?.users ?? 0, suffix: "" },
    { label: "Akun Disetor", value: data?.submissions ?? 0, suffix: "" },
    { label: "Akun Disetujui", value: data?.accepted ?? 0, suffix: "" },
    { label: "Total Pembayaran", value: data?.totalPaid ?? 0, prefix: "Rp" },
  ];

  return (
    <section className="mx-auto mt-24 max-w-6xl px-4">
      <div className="glass rounded-3xl p-6 md:p-10">
        <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="text-center"
            >
              <div className="text-3xl font-bold md:text-4xl gradient-text">
                <Counter to={s.value} prefix={s.prefix} suffix={s.suffix} />
              </div>
              <div className="mt-1 text-xs uppercase tracking-wide text-muted-foreground">{s.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
