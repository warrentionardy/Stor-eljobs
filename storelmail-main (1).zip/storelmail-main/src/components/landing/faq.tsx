import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { SectionHeader } from "./features";

const faqs = [
  { q: "Berapa lama proses verifikasi?", a: "Sebagian besar setoran diverifikasi dalam beberapa jam. Batch besar bisa sampai 24 jam." },
  { q: "Akun seperti apa yang memenuhi syarat?", a: "Akun harus asli, tidak dipakai untuk spam, sesuai prefix dan password yang tercantum pada bagian Rules Hari Ini." },
  { q: "Kapan saya bisa menarik saldo?", a: "Anda bisa mengajukan penarikan setelah mencapai minimum Rp10.000. Pencairan diproses dalam 24 jam." },
  { q: "Apakah data saya aman?", a: "Ya. Semua data dienkripsi saat transit dan disimpan, dengan kontrol akses berbasis peran yang ketat." },
  { q: "Metode pembayaran apa yang didukung?", a: "Saat ini penarikan hanya melalui DANA." },
];

export function FAQ() {
  return (
    <section id="faq" className="mx-auto mt-32 max-w-3xl px-4">
      <SectionHeader eyebrow="FAQ" title="Jawaban atas pertanyaan umum" />
      <div className="mt-10 glass rounded-3xl p-2 md:p-4">
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((f, i) => (
            <AccordionItem key={i} value={`i-${i}`} className="border-b last:border-b-0 px-3">
              <AccordionTrigger className="text-left text-base font-semibold">{f.q}</AccordionTrigger>
              <AccordionContent className="text-sm text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
