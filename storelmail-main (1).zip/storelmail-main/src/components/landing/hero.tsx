import { motion } from "framer-motion";
import { Link } from "@tanstack/react-router";
import { ArrowRight, Sparkles, ShieldCheck, Zap, CheckCircle2, Mail, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { money } from "@/lib/format";

async function fetchHeroStats() {
  const [subs, accepted, pending, paidWD] = await Promise.all([
    supabase.from("submissions").select("id", { count: "exact", head: true }),
    supabase.from("submissions").select("id", { count: "exact", head: true }).eq("status", "accepted"),
    supabase.from("submissions").select("id", { count: "exact", head: true }).eq("status", "pending"),
    supabase.from("withdrawals").select("amount").eq("status", "paid"),
  ]);
  const totalPaid = (paidWD.data ?? []).reduce((s, w) => s + Number(w.amount ?? 0), 0);
  return {
    disetor: subs.count ?? 0,
    diterima: accepted.count ?? 0,
    menunggu: pending.count ?? 0,
    totalPaid,
  };
}

export function Hero() {
  return (
    <section id="home" className="relative overflow-hidden pt-16 md:pt-24">
      <div className="mx-auto max-w-6xl px-4">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 rounded-full border bg-card/60 px-3 py-1 text-xs font-medium text-muted-foreground backdrop-blur">
              <Sparkles className="h-3.5 w-3.5 text-brand-accent" />
              Saldo real-time & pencairan cepat
            </div>
            <h1 className="mt-5 text-4xl font-bold leading-[1.05] tracking-tight md:text-6xl">
              Jual Akun Gmail yang Memenuhi Syarat{" "}
              <span className="gradient-text">Cepat & Aman</span>
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg">
              Platform terpercaya untuk memverifikasi akun email yang memenuhi syarat dan mendapatkan bayaran — dashboard rapi, saldo real-time, dan penarikan cepat.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link to="/auth">
                <Button size="lg" className="rounded-full gradient-brand text-white shadow-soft border-0 h-12 px-6">
                  Mulai Sekarang <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </Link>
              <a href="#how">
                <Button size="lg" variant="outline" className="rounded-full h-12 px-6">Pelajari</Button>
              </a>
            </div>
            <div className="mt-8 flex flex-wrap items-center gap-5 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="h-4 w-4 text-success" /> Tanpa biaya tersembunyi</span>
              <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="h-4 w-4 text-success" /> Terenkripsi menyeluruh</span>
              <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="h-4 w-4 text-success" /> Dukungan 24/7</span>
            </div>
          </motion.div>

          <HeroIllustration />
        </div>
      </div>
    </section>
  );
}

function HeroIllustration() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["hero-stats"], queryFn: fetchHeroStats });

  useEffect(() => {
    const ch = supabase
      .channel("hero-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "submissions" }, () => qc.invalidateQueries({ queryKey: ["hero-stats"] }))
      .on("postgres_changes", { event: "*", schema: "public", table: "withdrawals" }, () => qc.invalidateQueries({ queryKey: ["hero-stats"] }))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [qc]);

  const empty = !data || (data.disetor === 0 && data.diterima === 0 && data.menunggu === 0 && data.totalPaid === 0);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.7, delay: 0.1 }}
      className="relative mx-auto w-full max-w-lg"
    >
      <div className="absolute -inset-6 gradient-brand opacity-30 blur-3xl rounded-full" />
      <div className="glass relative rounded-3xl p-5 shadow-soft">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-xl gradient-brand"><Mail className="h-4 w-4 text-white" /></div>
            <div>
              <div className="text-xs text-muted-foreground">Total dibayarkan</div>
              <div className="text-lg font-bold">
                {isLoading ? <Loader2 className="h-4 w-4 animate-spin inline" /> : money(data?.totalPaid ?? 0)}
              </div>
            </div>
          </div>
          <div className="rounded-full bg-success/15 px-3 py-1 text-xs font-medium text-success">Live</div>
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2">
          {[
            { l: "Disetor", v: data?.disetor ?? 0 },
            { l: "Diterima", v: data?.diterima ?? 0 },
            { l: "Menunggu", v: data?.menunggu ?? 0 },
          ].map((s) => (
            <div key={s.l} className="rounded-2xl bg-accent/60 p-3">
              <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{s.l}</div>
              <div className="text-base font-semibold">{s.v.toLocaleString("id-ID")}</div>
            </div>
          ))}
        </div>

        {empty ? (
          <div className="mt-4 grid h-32 place-items-center rounded-2xl bg-accent/50 p-3 text-xs text-muted-foreground">
            Belum Ada Data
          </div>
        ) : (
          <div className="mt-4 h-32 rounded-2xl bg-accent/50 p-3">
            <div className="mb-2 text-xs text-muted-foreground">Aktivitas platform</div>
            <svg viewBox="0 0 200 80" className="h-full w-full">
              <defs>
                <linearGradient id="g" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="0%" stopColor="oklch(0.75 0.14 235)" stopOpacity="0.6" />
                  <stop offset="100%" stopColor="oklch(0.75 0.14 235)" stopOpacity="0" />
                </linearGradient>
              </defs>
              <path d="M0,60 C30,40 50,55 70,35 C90,15 110,45 130,25 C150,10 175,30 200,15 L200,80 L0,80 Z" fill="url(#g)" />
              <path d="M0,60 C30,40 50,55 70,35 C90,15 110,45 130,25 C150,10 175,30 200,15" fill="none" stroke="oklch(0.55 0.22 262)" strokeWidth="2.5" />
            </svg>
          </div>
        )}
      </div>

      <motion.div
        animate={{ y: [0, -10, 0] }}
        transition={{ duration: 4, repeat: Infinity }}
        className="glass absolute -left-6 top-14 flex items-center gap-2 rounded-2xl px-3 py-2 shadow-soft"
      >
        <div className="grid h-8 w-8 place-items-center rounded-xl bg-success/15"><ShieldCheck className="h-4 w-4 text-success" /></div>
        <div>
          <div className="text-[11px] text-muted-foreground">Diterima</div>
          <div className="text-xs font-semibold">{(data?.diterima ?? 0).toLocaleString("id-ID")}</div>
        </div>
      </motion.div>

      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 5, repeat: Infinity }}
        className="glass absolute -right-4 bottom-8 flex items-center gap-2 rounded-2xl px-3 py-2 shadow-soft"
      >
        <div className="grid h-8 w-8 place-items-center rounded-xl bg-brand-accent/15"><Zap className="h-4 w-4 text-brand-accent" /></div>
        <div>
          <div className="text-[11px] text-muted-foreground">Total dibayarkan</div>
          <div className="text-xs font-semibold">{money(data?.totalPaid ?? 0)}</div>
        </div>
      </motion.div>
    </motion.div>
  );
}
