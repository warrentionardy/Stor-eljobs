import { motion } from "framer-motion";
import { Megaphone } from "lucide-react";
import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { SectionHeader } from "./features";
import { dateTime } from "@/lib/format";

export function Testimonials() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["landing-announcements"],
    queryFn: async () => {
      const { data } = await supabase
        .from("announcements")
        .select("id, title, message, created_at")
        .order("created_at", { ascending: false })
        .limit(4);
      return data ?? [];
    },
  });

  useEffect(() => {
    const ch = supabase
      .channel("landing-announcements-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "announcements" }, () =>
        qc.invalidateQueries({ queryKey: ["landing-announcements"] })
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [qc]);

  if (!data || data.length === 0) return null;

  return (
    <section className="mx-auto mt-32 max-w-6xl px-4">
      <SectionHeader eyebrow="Pengumuman" title="Kabar terbaru dari platform" />
      <div className="mt-10 grid gap-4 md:grid-cols-2">
        {data.map((a, i) => (
          <motion.div
            key={a.id}
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.05 }}
            className="glass rounded-3xl p-5"
          >
            <div className="flex items-center gap-2 text-brand-accent">
              <Megaphone className="h-4 w-4" />
              <div className="text-xs font-semibold uppercase tracking-wide">Pengumuman</div>
            </div>
            <div className="mt-2 text-lg font-semibold">{a.title}</div>
            <p className="mt-1 text-sm text-muted-foreground">{a.message}</p>
            <div className="mt-3 text-xs text-muted-foreground">{dateTime(a.created_at)}</div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
