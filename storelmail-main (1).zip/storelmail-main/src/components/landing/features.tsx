import { motion } from "framer-motion";
import { Zap, Wallet, ShieldCheck, LayoutDashboard, ListChecks, LifeBuoy } from "lucide-react";

const features = [
  { icon: Zap, title: "Verifikasi Cepat", body: "Sebagian besar setoran diverifikasi dalam hitungan jam oleh tim dan sistem kami." },
  { icon: Wallet, title: "Pencairan Cepat", body: "Tarik dana begitu mencapai minimum. Pembayaran diproses kurang dari 24 jam." },
  { icon: ShieldCheck, title: "Platform Aman", body: "Enkripsi menyeluruh, kontrol akses ketat, dan infrastruktur teraudit." },
  { icon: LayoutDashboard, title: "Dashboard Pengguna", body: "Pantau saldo, setoran, dan pencairan dalam antarmuka real-time yang rapi." },
  { icon: ListChecks, title: "Pelacakan Setoran", body: "Lihat status tiap akun: menunggu, diterima, atau ditolak dengan riwayat lengkap." },
  { icon: LifeBuoy, title: "Dukungan Profesional", body: "Tim dukungan siap menjawab pertanyaan dan menyelesaikan masalah dengan cepat." },
];

export function Features() {
  return (
    <section id="features" className="mx-auto mt-32 max-w-6xl px-4">
      <SectionHeader eyebrow="Fitur" title="Semua yang Anda butuhkan untuk menghasilkan" desc="Perangkat yang dirancang untuk kecepatan, kejelasan, dan keandalan." />
      <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {features.map((f, i) => (
          <motion.div
            key={f.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.06 }}
            whileHover={{ y: -4 }}
            className="group glass rounded-3xl p-6 transition"
          >
            <div className="grid h-11 w-11 place-items-center rounded-2xl gradient-brand shadow-soft">
              <f.icon className="h-5 w-5 text-white" />
            </div>
            <div className="mt-4 text-lg font-semibold">{f.title}</div>
            <p className="mt-1.5 text-sm text-muted-foreground">{f.body}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

export function SectionHeader({ eyebrow, title, desc }: { eyebrow: string; title: string; desc?: string }) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <div className="inline-flex items-center rounded-full border bg-card/60 px-3 py-1 text-[11px] font-semibold uppercase tracking-wide text-brand-accent">{eyebrow}</div>
      <h2 className="mt-4 text-3xl font-bold tracking-tight md:text-4xl">{title}</h2>
      {desc && <p className="mt-3 text-muted-foreground">{desc}</p>}
    </div>
  );
}
