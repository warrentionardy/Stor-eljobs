import { CheckCircle2, XCircle } from "lucide-react";

export function PrefixBadge({ valid, reason }: { valid: boolean | null | undefined; reason?: string | null }) {
  const ok = valid !== false;
  return (
    <span
      title={reason ?? undefined}
      className={`inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2 py-0.5 text-[10px] font-semibold ${
        ok ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"
      }`}
    >
      {ok ? <CheckCircle2 className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
      {ok ? "Valid Prefix" : "Invalid Prefix"}
    </span>
  );
}