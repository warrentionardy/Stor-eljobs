import { SidebarTrigger } from "@/components/ui/sidebar";
import { Bell, Moon, Sun } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";

export function AppTopbar({ title }: { title: string }) {
  const [dark, setDark] = useState(false);
  useEffect(() => { setDark(document.documentElement.classList.contains("dark")); }, []);
  const toggle = () => {
    const n = !dark;
    setDark(n);
    document.documentElement.classList.toggle("dark", n);
    localStorage.setItem("elmail-theme", n ? "dark" : "light");
  };

  return (
    <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-border/60 bg-background/70 px-4 backdrop-blur">
      <SidebarTrigger />
      <h1 className="truncate text-sm font-semibold">{title}</h1>
      <div className="ml-auto flex items-center gap-2">
        <button onClick={toggle} className="grid h-9 w-9 place-items-center rounded-full border hover:bg-accent" aria-label="Toggle theme">
          {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </button>
        <Link to="/dashboard/notifications" className="grid h-9 w-9 place-items-center rounded-full border hover:bg-accent">
          <Bell className="h-4 w-4" />
        </Link>
      </div>
    </header>
  );
}
