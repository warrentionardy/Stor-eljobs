import { Check, X, Tag, Info } from "lucide-react";
import { useRule } from "@/hooks/use-rule";
import { buildExamples, normalizePrefix } from "@/lib/prefix";
import { money, dateTime } from "@/lib/format";

/** Rules Hari Ini preview with auto-generated valid/invalid examples from today's rule. */
export function RulesPreview() {
  const { data: rule, isLoading } = useRule();
  const prefix = normalizePrefix(rule?.prefix);
  const examples = buildExamples(prefix);

  if (isLoading) return <div className="glass rounded-3xl p-5 text-sm text-muted-foreground">Memuat aturan...</div>;
  if (!rule) return <div className="glass rounded-3xl p-5 text-sm text-muted-foreground">Belum ada aturan aktif.</div>;

  return (
    <div className="glass rounded-3xl p-5">
      <div className="mb-3 flex items-center justify-between">
        <div className="text-sm font-semibold">Rules Hari Ini</div>
        <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${rule.is_active ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"}`}>
          {rule.is_active ? "Aktif" : "Nonaktif"}
        </span>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-2xl bg-accent/50 p-3">
          <div className="flex items-center gap-1 text-xs text-muted-foreground"><Tag className="h-3 w-3" /> Prefix hari ini</div>
          <div className="mt-1 font-mono text-lg font-bold">{prefix || "-"}</div>
        </div>
        <div className="rounded-2xl bg-success/10 p-3">
          <div className="text-xs text-success">Harga jika prefix cocok</div>
          <div className="mt-1 font-semibold text-success">{money(rule.price_match)}</div>
        </div>
        <div className="rounded-2xl bg-warning/10 p-3">
          <div className="text-xs text-warning">Harga jika prefix tidak cocok</div>
          <div className="mt-1 font-semibold text-warning">{money(rule.price_no_match)}</div>
        </div>
      </div>

      {prefix && (
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <div className="rounded-2xl bg-success/10 p-3">
            <div className="mb-2 flex items-center gap-1 text-xs font-semibold text-success"><Check className="h-3.5 w-3.5" /> Example Valid</div>
            <ul className="space-y-1 font-mono text-xs text-success">
              {examples.valid.map((e) => <li key={e}>✔ {e}</li>)}
            </ul>
          </div>
          <div className="rounded-2xl bg-destructive/10 p-3">
            <div className="mb-2 flex items-center gap-1 text-xs font-semibold text-destructive"><X className="h-3.5 w-3.5" /> Example Invalid</div>
            <ul className="space-y-1 font-mono text-xs text-destructive">
              {examples.invalid.map((e) => <li key={e}>✖ {e}</li>)}
            </ul>
          </div>
        </div>
      )}

      {rule.notes && (
        <div className="mt-3 flex items-start gap-2 rounded-2xl border border-brand-accent/20 bg-brand-accent/5 p-3 text-xs">
          <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-brand-accent" />
          <div>{rule.notes}</div>
        </div>
      )}
      <div className="mt-3 text-xs text-muted-foreground">Terakhir diperbarui: {dateTime(rule.updated_at)}</div>
    </div>
  );
}