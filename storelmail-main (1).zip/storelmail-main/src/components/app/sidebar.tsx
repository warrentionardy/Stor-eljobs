import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard, Send, History, Wallet, BanknoteArrowUp, Bell, User as UserIcon, Settings, LogOut, ShieldCheck, Users, Gift,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarGroupContent,
  SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem, useSidebar,
} from "@/components/ui/sidebar";
import { Logo } from "@/components/site/logo";
import { useIsAdmin } from "@/hooks/use-auth";

const items = [
  { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard, exact: true },
  { title: "Setor Akun", url: "/dashboard/submit", icon: Send },
  { title: "Riwayat Setoran", url: "/dashboard/history", icon: History },
  { title: "Saldo", url: "/dashboard/balance", icon: Wallet },
  { title: "Tarik Saldo", url: "/dashboard/withdraw", icon: BanknoteArrowUp },
  { title: "Komunitas", url: "/dashboard/community", icon: Users },
  { title: "Referral", url: "/dashboard/referral", icon: Gift },
  { title: "Riwayat Referral", url: "/dashboard/referral-history", icon: History },
  { title: "Notifikasi", url: "/dashboard/notifications", icon: Bell },
  { title: "Profil", url: "/dashboard/profile", icon: UserIcon },
  { title: "Pengaturan", url: "/dashboard/settings", icon: Settings },
];

export function AppSidebar({ userId }: { userId?: string }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const isAdmin = useIsAdmin(userId);
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { state } = useSidebar();
  const collapsed = state === "collapsed";

  const isActive = (u: string, exact?: boolean) => exact ? path === u : path.startsWith(u);

  const logout = async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="p-3">
        {!collapsed ? <Logo /> : (
          <div className="grid h-9 w-9 place-items-center rounded-2xl gradient-brand mx-auto">
            <span className="text-white font-bold text-sm">E</span>
          </div>
        )}
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((i) => (
                <SidebarMenuItem key={i.url}>
                  <SidebarMenuButton asChild isActive={isActive(i.url, i.exact)} tooltip={i.title}>
                    <Link to={i.url}><i.icon /><span>{i.title}</span></Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
              {isAdmin && (
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={path.startsWith("/admin")} tooltip="Admin">
                    <Link to="/admin"><ShieldCheck /><span>Panel Admin</span></Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-3">
        <SidebarMenuButton onClick={logout} tooltip="Keluar">
          <LogOut /><span>Keluar</span>
        </SidebarMenuButton>
      </SidebarFooter>
    </Sidebar>
  );
}
