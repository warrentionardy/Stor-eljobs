import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import {
  LayoutDashboard, Users, FileSearch, Wallet, CreditCard, Megaphone, Settings, LogOut, ArrowLeft, ScrollText, KeyRound,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import {
  Sidebar, SidebarContent, SidebarFooter, SidebarGroup, SidebarGroupContent,
  SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem, useSidebar,
} from "@/components/ui/sidebar";
import { Logo } from "@/components/site/logo";

const items = [
  { title: "Dashboard", url: "/admin", icon: LayoutDashboard, exact: true },
  { title: "Rules Management", url: "/admin/rules", icon: ScrollText },
  { title: "Password Management", url: "/admin/password-categories", icon: KeyRound },
  { title: "Manajemen Pengguna", url: "/admin/users", icon: Users },
  { title: "Antrean Verifikasi", url: "/admin/queue", icon: FileSearch },
  { title: "Setoran", url: "/admin/submissions", icon: FileSearch },
  { title: "Permintaan Penarikan", url: "/admin/withdrawals", icon: Wallet },
  { title: "Manajemen Saldo", url: "/admin/payments", icon: CreditCard },
  { title: "Pengumuman", url: "/admin/announcements", icon: Megaphone },
  { title: "Pengaturan Platform", url: "/admin/settings", icon: Settings },
];

export function AdminSidebar() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const isActive = (u: string, exact?: boolean) => exact ? path === u : path.startsWith(u);

  const logout = async () => {
    await qc.cancelQueries(); qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="p-3">
        {!collapsed ? (
          <div className="flex items-center gap-2">
            <Logo />
            <span className="rounded-full bg-brand-accent/15 px-2 py-0.5 text-[10px] font-bold uppercase text-brand-accent">Admin</span>
          </div>
        ) : (
          <div className="grid h-9 w-9 place-items-center rounded-2xl gradient-brand mx-auto">
            <span className="text-white font-bold text-sm">A</span>
          </div>
        )}
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((i) => (
                <SidebarMenuItem key={i.url}>
                  <SidebarMenuButton asChild isActive={isActive(i.url, i.exact)} tooltip={i.title}>
                    <Link to={i.url}><i.icon /><span>{i.title}</span></Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
              <SidebarMenuItem>
                <SidebarMenuButton asChild tooltip="Kembali ke aplikasi">
                  <Link to="/dashboard"><ArrowLeft /><span>Dashboard Pengguna</span></Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-3">
        <SidebarMenuButton onClick={logout} tooltip="Keluar"><LogOut /><span>Keluar</span></SidebarMenuButton>
      </SidebarFooter>
    </Sidebar>
  );
}
